<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.1 - 24/08/13 22:47
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://www.w3schools.com/css/default.asp 
 * @see http://www.w3.org/TR/html401/types.html
 * @see http://www.w3.org/TR/html401/struct/links.html
 * @see http://www.quackit.com/html_5/tags/html_link_tag.cfm
 * @see http://www.w3schools.com/tags/att_style_scoped.asp
 * @link http://fsf.fabianosantos.net/index.php?action=package 
 * @since 0.1
 * @package Layout
 * @subpackage InterfaceWeb
 * @filesource class.html.css.php
 */
 
 /**
  * Classe utilizada para publicação de tags para uso em folhas de estilo - CSS.
 */

class HTML_CSS
{
    /** 
    * Retorna a TAG de CSS para arquivo externo.
    *
    * @acess public
    * @name html_css_link()	
    * @return string
    * 
    * 
    * @param string $url_css
    * Localização do arquivo.
    *
    * @param string $title
    * Informa o título da folha de estilo, se não inserido o valor padrão é 'default'
    *
    * @param bool $isXHTML
    * Se true (verdadeiro) retorna a TAG no formato XHTML.
    *
    * @param int $relation
    * Informa qual a relação que o arquivo externo tem com o documento em questão. 
    *
    * Segue valores aceitos:
    * <ul>
    * 	<li>Informando '1' é retornado 'stylesheet'.</li>
    * 	<li>2 retorna 'alternate'.</li>
    * 	<li>3 retorna'alternate stylesheet'.</li>
    * </ul>
    *
    * @param int $media
    *    
    * Suporta inteiros de 1 ao 8:
    * <ul>
    *	<li>Para o valor 1 o retorno é 'screen'.</li>
    *	<li>2 'print'.</li>
    *	<li>3 'handheld'.</li>
    *	<li>4 'tty'.</li>
    *	<li>5 'tv'.</li>
    *	<li>6 'projection'.</li>
    *	<li>7 'braille'.</li>
    *  	<li>Se o número 8 for informado (valor padrão) o parâmetro posterior $personalmedia poderá receber uma string.</li>
    * </ul>
    *
    * @param string $personalmedia
    * Valor default 'all'. 
    * Este parâmetro permite customizar o formato da midia
    *
    *
    * <b>Veja um exemplo de uso abaixo.</b>
    *	<code>
    *		require('/lib/FabianoSantosFramework/PHP/Codigos/Layout/InterfaceWeb/class.html.css.php');
    *		print html_css::html_css_link('base.css','',true);  
    *
    *		Resultado:
    *		<link rel="stylesheet" href="base.css" title="default" type="text/css" media="all" />
    *	</code>    
    *
    */
	
  public static function html_css_link($url_css,$title,$isXHTML,$relation=1,$media=8,$personalmedia='all')                                         
  {	
    #Variável referente a personalização da media alvo
    $pmedia='';
    
    switch($relation)
    {    
      case 1:
	    $relation='stylesheet';
	    break;	    
    
      case 2:
	    $relation='alternate';
	    break;	    
	    
      case 3:
	    $relation='alternate stylesheet';
	    break;	    
	    
      default:
	    throw new Exception('Quarto parâmetro <b>$relation</b> inválido. Apenas números de 1 a 3 são válidos.');
	    break;
    }
    
    if(empty($url_css))
      throw new Exception('Insira a URL do CSS. O primeiro parâmetro <b>$url_css</b> não pode ser vazio.');    
      
    else if(!preg_match('/\b.css\b$/i',$url_css))
      throw new Exception('Insira um CSS válido. O primeiro parâmetro <b>$url_css</b> deve terminar com <b>.css</b>.');    
     
    # não testado arquivo remotamente para não interferir na velocidade do carregamento da página
    else if(!preg_match('/^http:\/\//i',$url_css) && !preg_match('/^https:\/\//i',$url_css))
    {
      if(!@file_exists($url_css))
      throw new Exception('O primeiro parâmetro <b>$url_css</b> é inválido, o arquivo CSS especificado não existe ou está em um diretório diferente ! Crie o arquivo e atualize a página.');    
    }
      
    switch($media)
    {    
      case 1:
	    $media='screen';
	    break;	    
	    
      case 2:
	    $media='print';
	    break;	
	    
      case 3:
	    $media='handheld';
	    break;	    
	    	    
      case 4:
	    $media='tty';
	    break;	    
	    	    
      case 5:
	    $media='tv';
	    break;
	    
      case 6:
	    $media='projection';
	    break;

      case 7:
	    $media='braille';
	    break;	    

      case 8:
	    //Permite que o usuário personalize a midia
	    if(empty($personalmedia))
	      throw new Exception('Devido ao quinto parâmetro <b>$media</b> estar com a numeração customizada você deve especificar um valor para o sexto parâmetro <b>$personalmedia</b>.');        
	    
	    $pmedia=$personalmedia;
	    break;
	    
      default:
	    throw new Exception('O Quinto parâmetro <b>$media</b> aceita somente inteiro de 1 a 8.');        
	    break;
    }    

    if(empty($media))
        throw new Exception('Insira um valor para o <b>$media</b>.');        

    if(empty($title))
        $title='default';

    //indica o caractere barra 
    $ch = ''; 
    
    if(!is_bool($isXHTML)) throw new Exception('Terceiro parâmetro <b>$isXHTML</b> inválido. Aceito somente true e false.');        
    
    if($isXHTML)  $ch = ' /';
    
      if(!empty($pmedia))      
	return "<link rel=\"$relation\" href=\"$url_css\" title=\"$title\" type=\"text/css\" media=\"$pmedia\"$ch>\n";       
      else
	return "<link rel=\"$relation\" href=\"$url_css\" title=\"$title\" type=\"text/css\" media=\"$media\"$ch>\n";       
  }
  
  
    /**
    * 
    * Retorna a TAG Style para ser inserida no documento
    *
    * @acess public
    * @name html_css_inline()	
    * @return string
 
    * @param string $stylebody
    * Declaração CSS a ser inserida no documento
    * 
    * @param bool $isXHTML
    * Informa se a tag é 'true' ou não 'false' XHTML.<br />
    * Caso 'true' o atributo MIMETYPE também é inserido na TAG.   
    * 
    * @param bool $scope
    * Se este parâmetro for 'true', a tag STYLE pode ser inserida em qualquer elemento dentro da tag BODY.<br />
    * Caso insira a tag numa DIV, o STYLE funcionará apenas localmente e nas TAGS filhas desse DIV (only supported by Firefox).<br /><br />
    *
    * <b>Veja um exemplo de uso abaixo.</b>
    *	<code>
    *		require('/lib/FabianoSantosFramework/PHP/Codigos/Layout/InterfaceWeb/class.html.css.php');
    *		print html_css::html_css_inline('h1 {color:red}',false,true);
    *		
    *		Resultado:
    *		<div>
    *			<style scoped> 
    *				h1 {color:red}
    *			</style>
    *
    *			<h1>Your text here</h1>
    *			<p>This tag STYLE is at HTML5</p>    
    *		</div>
    *	</code>
    */
  
  public static function html_css_inline($stylebody, $isXHTML, $scope)
  { 
    if(empty($stylebody)) 
      throw new Exception('Primeiro parâmetro <b>$stylebody</b> vazio.');
    else
      $stylebody=strip_tags($stylebody);
    
    if(!is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente true e false.');            
    if(!is_bool($scope)) throw new Exception('Terceiro parâmetro <b>$scope</b> inválido. Aceito somente true e false.');            
    
      $type='';
      $scopec='';
      
    if($scope)
      $scopec=" scoped";
      
    if($isXHTML)
    {
      $scopec=" scoped=\"scoped\"";
      $type=" type=\"text/css\"";
    }
    
     if(!$scope)
      $scopec="";
    
    return "<style$type$scopec>\n\n$stylebody\n\n</style>";
  } 
}
?>