<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.2 - 03/09/2013 18:41
 * @since 0.1
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://gmpg.org/xfn/11
 * @see http://dublincore.org
 * @see https://developer.mozilla.org/pt/Utilizando_meta_tags
 * @see http://www.w3schools.com/tags/att_meta_http_equiv.asp
 * @see http://www.w3schools.com/tags/att_meta_scheme.asp  
 * @see http://www.i18nguy.com/markup/metatags.html
 * @see http://www.oficinadanet.com.br/artigo/573/resolvendo_o_problema_do_cache
 * @link http://fsf.fabianosantos.net/index.php?action=package 
 * @package HiperTexto
 * @subpackage MetaDados 
 */

 
 /**
  * Classe utilizada para gerar meta tags.
  */
 
class HTML_Meta
{  

  /** 
  * Retorna o meta autor do documento.
  *
  * @acess public
  * @name html_meta_author()	
  * @return string
  * 
  * @param string $author
  * Nome do autor do documento.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.	
  */
	
  public static function html_meta_author($author,$isXHTML)
  {
    if(empty($author))
      throw new Exception('Insira um autor do site !'); 

    else if(!is_string($author))                  
	  throw new Exception('O primeiro parâmetro <b>$author</b> deve ser uma string.');
	  
    else if(strlen($author)<2)
      throw new Exception('Caracteres insuficientes para o primeiro parâmetro <b>$author</b>.');     
      
    //remove html tags
    $a=strlen($author);
    $author=strip_tags($author);
    $d=strlen($author);  
    
    if($a!=$d) throw new Exception('Tags HTML (ou parte dela) não são permitidos como parâmetro !');
    //fim remove html tags      
	
    if(!is_bool($isXHTML))
      throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    return "<meta name=\"author\" content=\"$author\"$ch>";
  }

  
  
  /** 
  * Retorna o copyright do documento.
  *
  * @acess public
  * @name html_meta_copyright()	
  * @return string
  * 
  * @param string $copyright
  * Informa quem é o dono do documento. Normalmente utiliza-se o endereço de domínio como valor.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */
	
  public static function html_meta_copyright($copyright,$isXHTML)
  {
    if(!is_string($copyright))                  
	throw new Exception('O primeiro <b>$copyright</b> parâmetro deve ser uma string.');
	
    else if(empty($copyright))                  
	throw new Exception('O primeiro parâmetro <b>$copyright</b> não pode ficar vazio ! Informe de quem são os direitos da página/site.');
	
    else if(!is_string($copyright))                  
	throw new Exception('O primeiro <b>$copyright</b> parâmetro deve ser uma string.');

    //remove html tags
    $a=strlen($copyright);
    $copyright=strip_tags($copyright);
    $d=strlen($copyright);  
    
    if($a!=$d) throw new Exception('Tags HTML (ou parte dela) não são permitidos como parâmetro !');
    //fim remove html tags	
	
    if(!is_bool($isXHTML))
	throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
	
    if(empty($isXHTML) && !is_bool($isXHTML))
	throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    return "<meta name=\"copyright\" content=\"© $copyright\"$ch>";
  }

  
  /** 
  * Retorna a codificação de caracteres do documento.
  *
  * @acess public
  * @name html_meta_charset()	
  * @return string
  * 
  * @param string $charsetenc
  * Seta qual a codificação do documento. Para valores aceitáveis acesse: {@link http://en.wikipedia.org/wiki/Charset}.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  *
  *
  *
  * <b>Exemplo de utilização:</b>
  * <code>
  *	require('/lib/FabianoSantosFramework/PHP/Codigos/HiperTexto/InterfaceWeb/class.html.base.php');
  *	require('/lib/FabianoSantosFramework/PHP/Codigos/HiperTexto/MetaDados/class.html.meta.php');
  *
  *	$doc = HTML_Base::html_doctype(2);
  *	$html = HTML_Base::html(2, 1, 'pt-br');	
  *	$title = HTML_Base::html_title('Página de teste');
  *
  *	$meta = HTML_Meta::html_meta_charset('iso-8859-1',true);	
  *	$head = $title.$meta;	
  *
  *	$head = HTML_Base::html_head($head,false);
  *	$end = HTML_Base::html_end();
  *
  *	$body = '';
  *
  * 	if(empty($body))
  *	 $body	= "<body>
  *	 			 Essa página é de teste.
  *			     </body>";
  *	
  *	$nl = "\n";
  *	
  *	print		
  *			$doc.$nl.
  *			$html.$nl.
  *			$head.$nl.
  *			$body.$nl.
  *			$end;
  * </code>
  */	
	
  public static function html_meta_charset($charsetenc,$isXHTML)
  {
    $str="Insira, por exemplo, a codificação \"iso-5559-1\" para caracteres de lingua latina, e \"utf-8\" para todos idiomas (lembre-se de salvar o arquivo também com essa codificação de caractere, senão haverá distorção no caractere). Para uma lista de valores aceitáveis comuns acesse <a href=\"http://en.wikipedia.org/wiki/Charset#Common_character_encodings\" target=\"_blank\" title=\"Nova Janela\">codificação de caracteres</a>. Você também pode visualizar valores aceitáveis no menu de <em>codificação de caracteres</em> de seu navegador.";
    
    if(!is_string($charsetenc))                  
	throw new Exception('O primeiro <b>$charsetenc</b> parâmetro deve ser uma string. '. $str);

    else if(strlen($charsetenc)<2)
      throw new Exception('Caracteres insuficientes para o primeiro parâmetro <b>$charsetenc</b>. '. $str);     
    	
    $charsetenc = strtolower($charsetenc);

  if(!preg_match("/^[a-z]{0,10}[-{0,1}|_{0,1}][0-9]{0,4}[-{0,1}|_{0,1}][0-9]{1,2}$/",$charsetenc,$c))                
    {
	if(!preg_match("/^[a-z]{0,30}_{0,1}|-{0,1}[0-9]{0,2}$/",$charsetenc) || preg_match("/[\s]/",$charsetenc))
	throw new Exception("O primeiro parâmetro <em>charset</em> (codificação de caracteres do site) contém caracteres inválidos ou está vazio ! $str");
    }
    
    //remove html tags
    $a=strlen($charsetenc);
    $charsetenc=strip_tags($charsetenc);
    $d=strlen($charsetenc);  
    
    if($a!=$d) throw new Exception('Tags HTML (ou parte dela) não são permitidos como parâmetro !');
    //fim remove html tags
    
    if(!is_bool($isXHTML))
      throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido ! Aceito somente valores booleanos.');      
      
    else if(empty($isXHTML) && !is_bool($isXHTML))
	  throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido ! Aceito somente valores booleanos.');      

    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
	  $type="application/xhtml+xml";
    }
    else
    {
	    $type = "text/html";
    }

    return "<meta http-equiv=\"content-type\" content=\"$type; charset=$charsetenc\"$ch>";
  }

  
  /** 
  * Retorna um valor referente ao tipo de indexação do documento para os mecanismos de buscas (Robôs).
  *
  * @acess public
  * @name html_meta_robots()	
  * @return string
  * 
  * @param int $type_robots
  * Aceita valores inteiros de 1 a 5. Para os valores abaixo, o robô:
  * <ul>
  *	<li>1 (indexa, segue os links e arquiva)</li>
  *	<li>2 (indexa e segue os links)</li>
  *	<li>3 (não indexa e segue os links)</li>
  *	<li>4 (indexa e não segue os links)</li>
  *	<li>5 (não indexa e não segue os links)</li>
  * </ul>
  * 
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */ 
	
  public static function html_meta_robots($type_robots,$isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    if(!is_int($type_robots))
      throw new Exception('Primeiro parâmetro <b>$type_robots</b> inválido ! Aceito somente valores inteiros.');	
    
    $r = "";

    switch($type_robots)
    {
      case 1:
        $r = "<meta name=\"robots\" content=\"all\"$ch>";
	break;
      case 2:
	$r = "<meta name=\"robots\" content=\"index,follow\"$ch>";
	break;
      case 3:
	$r = "<meta name=\"robots\" content=\"noindex,follow\"$ch>";
	break;
      case 4:
	$r = "<meta name=\"robots\" content=\"index,nofollow\"$ch>";        
	break;
      case 5:
	$r = "<meta name=\"robots\" content=\"noindex,nofollow\"$ch>";
	break;
      default:
	throw new Exception("Você deve especificar o tipo de visibilidade de sua página para os mecanismos de pesquisa. Aceito somente valores inteiros de 1 a 5.");	
	break;
    }   

    if(!is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    else if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    return $r;
  }
  
  /** 
  * Retorna a descrição do conteúdo documento.
  *
  * @acess public
  * @name html_meta_description()	
  * @return string
  * 
  * @param string $desc
  * Descrição do conteúdo do documento.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */  
	  
  public static function html_meta_description($desc,$isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    if(!is_string($desc)) throw new Exception('O primeiro parâmetro <b>$desc</b> é inválido ! Aceitável somente string.');
    else if(empty($desc) || strlen($desc)<=4)  throw new Exception('O primeiro parâmetro <b>$desc</b> está vazio ou possui menos de 4 caracteres !');
    
    if(!is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    else if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    return "<meta name=\"description\" content=\"$desc\"$ch>";
  }
  

  /** 
  * Retorna a descrição do conteúdo documento.
  *
  * @acess public
  * @name html_meta_keywords()	
  * @return string
  *
  * @param string $key
  * Informa as palavras chaves usadas na identificação do site por mecanismos de busca.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */  
	    
  public static function html_meta_keywords($key,$isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    if(!is_string($key)) throw new Exception('O primeiro parâmetro <b>$key</b> é inválido ! Aceitável somente string.');
    else if(empty($key) && strlen($key)<=4)  throw new Exception('O primeiro parâmetro <b>$key</b> está vazio ou possui menos de 4 caracteres !');
    
    if(!is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    else if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    return "<meta name=\"keywords\" content=\"$key\"$ch>";
  }
  
  
  /** 
  * Essa é uma tag inteligente criada pela Microsoft no Office XP para reconhecer dados personalizados no Documento. Você pode desabilitar essa função com essa meta tag.
  *
  * @acess public
  * @name html_meta_msoprevent()	
  * @return string
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */ 
	
  public static function html_meta_msoprevent($isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if(!is_bool($isXHTML)) throw new Exception('Primeiro parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    else if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Primeiro parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');

    return "<meta name=\"MSSmartTagsPreventParsing\" content=\"true\"$ch>";
  }

  /** 
  * Habilita ou desabilita o menu de ferramentas sobre qualquer figura no navegador.
  *
  * @acess public
  * @name html_meta_imagetoolbar()	
  * @return string
  *
  * @param bool $bpermission
  * Informa se aceita (true) ou não (false) a barra de ferramenta.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */ 
	
  public static function html_meta_imagetoolbar($bpermission, $isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
        
    if(!is_bool($bpermission))
      throw new Exception('Primeiro parâmetro <b>$bpermission</b> inválido. Aceito somente valores booleanos.');
    
    if(!is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    else if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
	
    $sp='';
    if($bpermission)
      $sp='yes';
    else 
      $sp='no';
      
    return "<meta http-equiv=\"imagetoolbar\" content=\"$sp\"$ch>";
  } 

  /** 
  * Permite personalizar a meta tag.
  *
  * @acess public
  * @name html_meta_personal()	
  * @return string
  *
  * @param string $nameMeta
  * Nome que identifica o propósito da tag.
  *
  * @param string $value
  * Informa o conteúdo do meta.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *	
  * @param string $format
  * Informa o esquema (scheme) da tag. 	
  */ 
	
  public static function html_meta_personal($nameMeta, $value, $isXHTML, $format='')
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
  
      if(strlen($nameMeta)<3 || preg_match('/^[0-9]/',$nameMeta) || empty($value))
      throw new Exception('Um ou mais parâmetros não foram preeenchidos corretamente. '.
      'O nome do <em>$nameMeta</em> (1° parâmetro) deve ter no mínimo 3 caracteres e não pode iniciar com número; '.
	  'o 2° <em>$value</em> não pode ficar vazio.');

      if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Terceiro parâmetro <em>$isXHTML</em> inválido. Aceita somente valores true ou false.');
      if(!empty($format)) $scheme="scheme=\"$format\"";
	  
	  
    return "<meta name=\"$nameMeta\" content=\"$value\" $scheme$ch>";
  }    


  /** 
  * Retorna o idioma do documento.
  *
  * @acess public
  * @name html_meta_lang()	
  * @return string
  * 
  * @param string $lang
  * Idioma do documento. Os valores válidos são encontrados em: {@link http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx}.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */
	
  public static function html_meta_lang($lang,$isXHTML)
  { 
    if(!ctype_alpha($lang) && !strpos($lang,'-'))                  
	throw new Exception("Insira o idioma do site, por exemplo, \"pt-br\" para Português Brasileiro ! Para outras linguagens ver valores aceitáveis em <a href=\"http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx\" target=\"_blank\" title=\"Nova Janela\">códigos de linguagem</a>.");

     if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro isXHTML inválido. Aceita somente valores true ou false.');

    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    return "<meta name=\"language\" content=\"$lang\"$ch>";
  }

  
  /** 
  * Retorna o idioma (HTTP) do documento.
  *
  * @acess public
  * @name html_meta_httplang()	
  * @return string
  * 
  * @param string $lang
  * Idioma do documento. Os valores válidos são encontrados em: {@link http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx}.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.		
  */
	
  public static function html_meta_httplang($lang,$isXHTML)
  {
  
    if(!ctype_alpha($lang) && !strpos($lang,'-'))                  
	throw new Exception("Insira o idioma do site, por exemplo, \"pt-br\" para Português Brasileiro ! Para outras linguagens ver valores aceitáveis em <a href=\"http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx\" target=\"_blank\" title=\"Nova Janela\">códigos de linguagem</a>.");

    if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro isXHTML inválido. Aceita somente valores true ou false.');

    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }

    return "<meta http-equiv=\"content-language\" content=\"$lang\"$ch>";
  }

  
  /** 
  * Permite redirecionar um documento.
  *
  * @acess public
  * @name html_meta_refresh()	
  * @return string
  *
  * @param string $src
  * Documento destino.
  *  
  * @param int $time
  * Tempo em segundos.
  *
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *      
  */
  
  public static function html_meta_refresh($src,$time,$isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if(empty($src)) throw new Exception('Primeiro parâmetro <em>$src inválido</em>. Preencha com a localização do documento.');
    if(!is_int($time)) throw new Exception('Segundo parâmetro <em>$time</em> inválido. Aceito somente números.');
    if(!is_bool($isXHTML)) throw new Exception('Terceiro parâmetro <em>$isXHTML</em> inválido. Aceito somente valores booleanos.');
        
    return "<meta http-equiv=\"refresh\" content=\"$time; url=$src\"$ch>";
  }
    

  /**
  *
  * Informa qual o nome do programa utilizado para gerar a página
  *
  * @acess public
  * @name html_meta_generator()	
  * @return string
  *
  * @param string $program
  * O nome do programa
  *  
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *      
  */
    
  public static function html_meta_generator($program, $isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    if(empty($program)) throw new Exception('Primeiro parâmetro <b>$program</b> vazio. Preencha com a localização do documento.');  
    
    return "<meta name=\"generator\" content=\"$program\"$ch>";  
  }
    

  /**
  *
  * Informa qual o nome do programa utilizado para gerar a página
  *
  * @acess public
  * @name html_meta_cache()	
  * @return string
  *
  * @param int $typeCache
  * Aceita números de 1 a 4 referente aos tipos de cache:
  * <ul>
  *	<li>1 'no-cache' - Não guarda em cache.</li>
  *	<li>2 'no-store' - Guarda em cache mas não arquiva.</li>
  *	<li>3 'public' - Pode armazenar em cache em servidores públicos.</li>  
  *	<li>4 'private' - Cache somente privado.</li>
  * </ul>
  *  
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *      
  */
    
  public static function html_meta_cache($typeCache, $isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if($typeCache == 1)
        $info = "<meta http-equiv=\"pragma\" content=\"no-cache\"$ch>\n<meta http-equiv=\"cache-control\" content=\"no-cache\"$ch>";
     elseif($typeCache == 2)
        $info = "<meta http-equiv=\"cache-control\" content=\"no-store\"$ch>"; 
     elseif($typeCache == 3)
	$info = "<meta http-equiv=\"cache-control\" content=\"public\"$ch>";         
     elseif($typeCache == 4)
        $info = "<meta http-equiv=\"cache-control\" content=\"private\"$ch>";
     else
	  throw new Exception('Primeiro parâmetro <b>$typeCache</b> inválido ! Aceito somente valores inteiros de 1 a 4.');

    if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    
    return $info;
  }    


  /**
  *
  * Informa a data de expiração da página.
  *
  * @acess public
  * @name html_meta_expires()	
  * @return string
  *
  * @param string $date
  * Você pode inserir uma data no formato "Mon, 22 Jul 2002 11:12:01 GMT" ou "-1" que indica que a página está sempre atualizada.
  *  
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *      
  */  
  public static function html_meta_expires($date, $isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if(!is_string($date)) throw new Exception('Primeiro parâmetro <b>$date</b> inválido !');
    if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    
    return "<meta http-equiv=\"expires\" content=\"$date\"$ch>";
  }
  
  
  /**
  *
  * Informa aos servidores de proxy para refazer o cache da página depois de um tempo específico. 
  *
  * @acess public
  * @name html_meta_revisit()	
  * @return string
  *
  * @param string $revTime
  * Informa os dias para revisita em inglês como "7 days", "15 days" e "1 month".
  *  
  * @param bool $isXHTML
  * Se true (verdadeiro) retorna a TAG no formato XHTML.			
  *      
  */  
  public static function html_meta_revisit($revTime, $isXHTML)
  {
    //indica o caractere barra 
    $ch = '';

    if($isXHTML)
    {
      $ch = ' /';
    }
    
    if(!is_string($revTime)) throw new Exception('Primeiro parâmetro <b>$revTime</b> inválido !');    
    if(empty($isXHTML) && !is_bool($isXHTML)) throw new Exception('Segundo parâmetro <b>$isXHTML</b> inválido. Aceito somente valores booleanos.');
    
    return "<meta name=\"revisit-after\" content=\"$revTime\"$ch>";
  }      
}
?>