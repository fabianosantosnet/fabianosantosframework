<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.1 - 25/08/13 16:09
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @link http://fsf.fabianosantos.net/index.php?action=package 
 * @since 0.1
 * @package HiperTexto
 * @subpackage Mensagem
 */
 
 /**
  * Classe utilizada para mostrar mensagens padrões
 */

class HTML_Mensagem
{
    /** 
    *
    * Retorna uma mensagem JavaScript (caixa alert)
    *
    * @acess public
    * @name js_aviso()	
    * @return string     
    * 
    * @param string $title    
    * Título da caixa de mensagem
    *    
    * @param string $text
    * Texto da caixa de mensagem
    *
    * @param bool $isHTML5
    * Caso verdadeiro 'true' o elemento é HTML5, e portanto, é removido o atributo TYPE da TAG <script>, caso contrário, 'false' (valor padrão) o atributo permanece.    
    *
    * @param bool $force
    * Utilizado somente quando o navegador não consegue renderizar o JavaScript.<br />
    * Desde que não haja nenhum erro de sintaxe na string informada.<br /><br />
    *
    * <b>Exemplo de utilização</b>	
    *
    * <code>
    *		require('lib/FabianoSantosFramework/PHP/Codigos/HiperTexto/Mensagem/class.html.mensagem.php');
    *
    *		print html_mensagem::js_aviso("Título","Texto aqui");
    * </code>
    */
	
    public static function js_aviso($title, $text, $isHTML5=false, $force=false)
    {
    
      if(empty($title)) throw new Exception("Primeiro parâmetro <em>$title</em> vazio.");
      if(empty($text)) throw new Exception("Segundo parâmetro <em>$text</em> vazio.");
      if(!is_bool($isHTML5)) throw new Exception("Terceiro parâmetro <em>$isHTML5</em> inválido ! Aceito somente valores booleanos.");
      if(!is_bool($force)) throw new Exception("Quarto parâmetro <em>$force</em> inválido ! Aceito somente valores booleanos.");
      
      $title=strip_tags($title);
      $text=strip_tags($text);
      
      if(!$isHTML5)
	$html5=" type=\"text/javascript\"";
      else
	$html5='';	
      
	$msg= "
    <script$html5>
    /*<![CDATA[*/
	    ";
	if($force) $msg.="\n\twindow.onload=function()\n\t{";
	  
	  $msg.= "\n\t\talert(\"$title\\n\\n\\$text\\n \");\n";
	  
	if($force) $msg.="\t}\n";
	
	$msg.="
    /*]]>*/	 
    </script>
      ";
      
      return $msg;
    }



    /** 
    *
    * Retorna uma mensagem em HTML
    *
    * @acess public
    * @name html_aviso()	
    * @return string     
    * 
    * @param string $msg
    * Mensagem a ser apresentada
    *    
    * @param int $styleCode
    * Define qual o estilo será usado no elemento. São aceitos valores inteiros de 1 a 4:
    * <ul>
    * 	  <li>'1' Indicado para erros. Tamanho fixo.</li>
    * 	  <li>'2' Indicado para mensagens de sucesso. Tamanho fixo.</li>
    * 	  <li>'3' Indicado para mensagens em geral. Tamanho relativo ao container.</li>
    * 	  <li>'4' Habilita o terceiro parâmetro $class.</li>
    * </ul>
    *
    *
    * @param bool $class
    * Especifica o nome da classe CSS criada pelo usuário. O segundo parâmetro $styleCode deve estar com o valor 4 para habilitar esse parâmetro.
    *
    * <b>Exemplo de utilização</b>	
    *
    * <code>
    *		require('lib/FabianoSantosFramework/PHP/Codigos/HiperTexto/Mensagem/class.html.mensagem.php');
    *
    *		echo  html_mensagem::html_texto('Erro de preenchimento dos campos',4,'error');
    * </code>
    */
    
  public static function html_aviso($msg,$styleCode,$class='')
  {
    if(empty($msg)) throw new Exception('Primeiro parâmetro inválido ! Insira uma mensagem.');
    $style='';
    
    switch($styleCode)
    {
      case 1:
	      $stdefault=' style="margin:auto;width:500px;background-color:#ffb;color:red;font-weight:bold;padding:6pt;font-size:10pt;text-align:center;border-radius:5px;border:1px double #cfc"';
	      $style=$stdefault;
	      break;
	      
      case 2:      
	      $stdefault=' style="margin:auto;width:500px;background-color:#ffb;color:green;font-weight:bold;padding:6pt;font-size:10pt;text-align:center;border-radius:5px;border:1px double #cfc"';
	      $style=$stdefault;    
	      break;
	      
      case 3:
      	      $stdefault=' style="margin:auto;width:96%;background-color:#ffe;color:black;font-weight:bold;padding:6pt;font-size:10pt;text-align:center;border-radius:5px;border:1px double #cfc"';
      	      $style=$stdefault;    
	      break; 
	      
      case 4:	      
	      if(empty($class)) throw new Exception("Terceiro parâmetro inválido ! Insira uma classe para o elemento HTML.");
	      else $style=" class=\"".$class."\"";
	    break;
      default:
      	      throw new Exception("Segundo parâmetro inválido ! Insira um inteiro de 1 a 4. Caso queira inserir uma classe sua escolha o número 4, para os demais valores há um style inline associado.");
	      break;
    }
    
    return '<div'.$style.'>'.$msg.'</div>';
  }  
}
?>