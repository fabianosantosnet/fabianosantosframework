<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.2 - 03/09/13 18:36
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://www.w3schools.com/html/default.asp
 * @see http://www.w3.org/TR/html4/struct/global.html
 * @see http://reference.sitepoint.com/html/head/profile  
 * @link http://fsf.fabianosantos.net/index.php?action=package 
 * @since 0.1
 * @package HiperTexto
 * @subpackage InterfaceWeb
 */
 
 /**
  * Classe que produz o HTML básico válido.
 */

class HTML_Base
{
  /** 
  * Retorna a Especificação do Documento de acordo com o parâmetro informado
  *
  * @acess public
  * @name html_doctype()	
  * @return string
  * 
  * 
  * @param int $doctype
  * Este parâmetro aceita somente inteiros de 1 a 8, cada um deles retorna um tipo 'Especificação de Documento'.<br />
  * Informando o valor: 1  retorna o tipo ( XHTML 1.0 Strict ), 2  ( XHTML 1.0 Transitional ), 3  ( XHTML 1.0 Frameset ),<br />
  * 4 (XHTML1.1), 5 (HTML5) <b>este é o valor padrão</b> , 6 ( HTML 4.01 Strict ), 7 ( HTML 4.01 Transitional ), 8  ( HTML 4.01 Frameset)
  */
      
  public static function html_doctype($doctype=5)
  {
    $selected = "";

    if($doctype == 1)
	$selected = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">';
    elseif($doctype == 2)
	$selected = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
    elseif($doctype == 3)
	$selected = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">';
    elseif($doctype == 4)
	# Este DTD é igual ao XHTML 1.0 Strict, mas permite adição de módulos
	$selected = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">';
    elseif($doctype == 5)
	$selected = '<!DOCTYPE html>';
    elseif($doctype == 6)
	$selected = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">';
    elseif($doctype == 7)
	$selected = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
    elseif($doctype == 8)
	$selected = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">';
    else
	throw new Exception("Parâmetro inválido ! Aceito somente números inteiros de 1 á 8.<br />
			    <ul>
			      <li>Número 1  ( XHTML 1.0 Strict ),</li>
			      <li>2  ( XHTML 1.0 Transitional ),</li>
			      <li>3  ( XHTML 1.0 Frameset ),</li>
			      <li>4 (XHTML1.1),</li>
			      <li>5 (HTML5),</li>
			      <li>6 ( HTML 4.01 Strict ),</li>
			      <li>7 ( HTML 4.01 Transitional ) e</li>
			      <li>8  ( HTML 4.01 Frameset).</li>
			     </ul>
			     ");
  
    return $selected;
  }

  
  /**
  * Retorna a tag inicial html com seus atributos.
  *
  * @access public
  * @name html()
  * @return string
  *
  * @param int $htmltype  
  * Aceita somente os valores inteiros 1 (documento HTML) e 2 (documento XHTML).
  *
  * @param int $dirtext  
  * Aceita somente os valores inteiros 1 (direção do texto da esquerda para direita) e 2 (direção do texto da direita para esquerda).<br /><br />
  *  
  * @param string $lang  
  * Define o idioma do HTML/XHTML no documento.<br />Valores válidos em: http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx<br /><br />
  *  
  * @param string $xmllang 
  * Define o idioma do XML do documento.<br />Valores válidos em: http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx
  *  
  */
  
  public static function html($htmltype=1,$dirtext=1,$lang='pt-br',$xmllang='pt-br')
  {
    #vars
    $selected="";
    $dirseltext="";

    #ini 2° param 
    if($dirtext == 1)
      $dirseltext = "\"ltr\"";
      
    elseif($dirtext == 2)
      $dirseltext = "\"rtl\"";
      
    else 
      throw new Exception('Parâmetro inválido para o segundo argumento (direção do texto) <em>$dirtext</em> !'.
			  'Aceito somente números inteiros: <b>1</b> (padrão ocidental) e <b>2</b>.');    
    #fim 2º param
    
    
    
    #ini 3º param 
    $lang = strtolower($lang);    
    
    if(!ctype_alpha($lang) && !strpos($lang,'-'))            
      throw new Exception('Parâmetro inválido para o terceiro argumento (lingua do html) <em>$lang</em> ! Ver valores aceitáveis em '.
	  '<a href="http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx" target="_blank" title="Nova Janela">códigos de linguagem</a>.');

    $lang = "\"".$lang."\"";
    #fim 3º param 


    #ini 4º param 
    #parametro válido apenas para XHTML 
    if($htmltype == 2)
    {
	$xmllang = strtolower($xmllang);    
	if(!ctype_alpha($xmllang) && !strpos($xmllang,'-'))            
	  throw new Exception('Parâmetro inválido para o quarto argumento (lingua do xml namespace) <em>$xmllang</em> ! Ver valores aceitáveis em '.
	  '<a href="http://msdn.microsoft.com/en-us/library/ms533052%28v=vs.85%29.aspx" target="_blank" title="Nova Janela">códigos de linguagem</a>.');

	$xmllang = "\"".$xmllang."\"";
    }
    #fim 4º param 
    

    #ini 1º param Geral 
    if($htmltype == 1)
	$selected = "<html dir=$dirseltext lang=$lang>"; 
    elseif($htmltype == 2)
	$selected = "<html xmlns=\"http://www.w3.org/1999/xhtml\" dir=$dirseltext lang=$lang xml:lang=$xmllang>"; 
    else
	throw new Exception('Valor inválido para o primeiro parâmetro <em>$htmltype</em> ! Aceito somente números inteiros: 1 e 2.');
    #fim 1º param Geral 

      return $selected;
  }
  
  
  /** 
  * Retorna o cabeçalho do html com os atributos inclusos.
  *
  * @acess public
  * @name html_head()	
  * @return string
  * 
  * @param string $headElements
  * Recebe outros elementos que constarão entre o elemento
  * 	
  * @param bool $supportProfile
  * Inclui (true) ou não inclui (false) o atributo de perfil no documento.			
  * 
  * @param string $profile
  * Depende do parâmetro $supportProfile ser true.<br />
  * Você pode deixar vazio pois ele assume um valor padrão ou setar o uma URL que indica uma descrição de seu perfil.
  * 	
  */	  
	
  public static function html_head($headElements,$supportProfile,$profile='http://gmpg.org/xfn/11')
  {
    if(empty($headElements))
	throw new Exception('O primeiro parâmetro referente aos elementos que constarão na tag head <em>$headElements</em> não pode ficar vazio !');	    
	
    else if(!is_string($headElements))		
	throw new Exception('O primeiro parâmetro referente aos elementos que constarão na tag head <em>$headElements</em> deve ser uma string !');	    
		
    if(!is_bool($supportProfile))
    	throw new Exception('O segundo parâmetro <em>$supportProfile</em> aceita somente valores booleanos.');	    
    	
    else if(empty($profile))
    	throw new Exception('No terceiro parâmetro <em>$profile</em> nenhum valor foi definido, nesse caso deixe o segundo parâmetro com o valor <em>false</em>.');	    
		
    $fprofile ='';
    if($supportProfile)
    {
	$fprofile=" profile=\"$profile\"";
    }
	
    $head = "<head$fprofile>$headElements</head>";	

    return $head;
  }

  
  /** 
  * Retorna o titulo do documento html. 
  *
  * @acess public
  * @name html_title()	
  * @return string
  * 
  * @param string $title Recebe o título do documento. O atributo $title vazio gera uma exceção.
  *
  *
  * <b>Exemplo de utilização:</b>
  * <code>
  *	require('/lib/FabianoSantosFramework/PHP/Codigos/HiperTexto/InterfaceWeb/class.html.base.php');
  *
  *	$doc   = HTML_Base::html_doctype(2);
  *	$html  = HTML_Base::html(2, 1, 'pt-br');	
  *	$title = HTML_Base::html_title('Página de teste');
  *	$head  = HTML_Base::html_head($title,false);
  *	$end   = HTML_Base::html_end();
  *	
  *	$body  = "<body>Corpo da página</body>";
  *	
  *	$nl    = "\n";
  *	
  *	print
  *	          $doc.$nl.
  *	          $html.$nl.
  *	          $head.$nl.
  *	          $body.$nl.
  *	          $end;
  * </code>
  */	 
	
  public static function html_title($title)
  {
    if(empty($title))
      throw new Exception('Insira um título para a página !');
      
    else if(!is_string($title))
      throw new Exception('O título deve ser uma string !');
    
    return "<title>$title</title>";
  }  
  

  /** 
  * Retorna a tag final html.
  *
  * @acess public
  * @name html_end()	
  * @return string
  */	
	
  public static function html_end()
  {
    return "</html>";
  }  
}
?>