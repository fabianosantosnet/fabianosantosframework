<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.3 - 19/09/2013 17:03
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://br2.php.net/manual/pt_BR/function.date.php
 * @see http://php.net/manual/en/function.date-default-timezone-set.php
 * @link http://fsf.fabianosantos.net/index.php?action=package
 * @since 0.1
 * @package Tempo
 * @subpackage Datas
 */

/**
 * Classe base utilizada para retornar todas as partes que compõem uma data, incluindo retornos em inglês/português e ordinais.
 */

class Base_Data
{
  /**
   * Propriedade que armazena o dia.
   * @acess private
   * @property int $dia
   */

    private $dia;

  /**
   * Propriedade que armazena o mês.
   * @acess private
   * @property int $mes
   */

    private $mes;

  /**
   * Propriedade que armazena o ano.
   * @acess private
   * @property int $ano
   */

    private $ano;

  /**
   * Propriedade que armazena o dia da semana.
   * @acess private
   * @property mixed $dia_da_semana
   */

    private $dia_da_semana;


  /**
   * Propriedade que armazena o dia do ano
   * @acess private
   * @property int $dia_do_ano
   */

    private $dia_do_ano;

  /**
   * Propriedade que indica se o ano é bissexto ou não.
   * @acess private
   * @property int $ano_bissexto
   */

    private $ano_bissexto;

  /**
   * Propriedade que armazena a quantidade de dias do mês atual.
   * @acess private
   * @property int $dias_deste_mes
   */

    private $dias_deste_mes;

  /**
   * Construtor inicializador das propriedades privadas referente a data.
   * @acess public
   * @name Base_Data
   *
   * @param string $setTimeZone
   * Define o timezone para a data.
   */

    public function Base_Data($setTimeZone='Europe/London')
    {
      #ini validacao
      if(!is_string($setTimeZone))
	  throw new Exception('Primeiro parâmetro <b>$setTimeZone</b> inválido ! Aceito somente strings.');	  	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no Contrutor da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
    
      #set Default Timezone      
      if(!@date_default_timezone_set($setTimeZone)) 
	throw new Exception('String de TimeZone Inválido para o parâmetro <b>$setTimeZone</b> ! Para uma lista válida de argumentos acesse: <a href="http://php.net/manual/en/function.date-default-timezone-set.php" target="_blank">http://php.net/manual/en/function.date-default-timezone-set.php</a>.');
     
      $this->dia = gmdate('d');
      $this->mes = gmdate('m');
      $this->ano = gmdate('Y');
      $this->dia_da_semana = gmdate('w');
      $this->dia_do_ano = gmdate('z');
      $this->ano_bissexto = gmdate('L');
      $this->dias_deste_mes = gmdate('t');
    }

  /**
   * Método que retorna o dia em inteiro de dois dígitos ou por extenso em inglês/português.
   * @acess public
   * @name getDia
   * @return mixed
   *
   * @param bool $retornar_texto
   * Parâmetro, opcional inicializado com o valor false, utilizado para habilitar ou desabilitar o retorno como texto.<br /><br />
   *
   * @param bool $is_english
   * Parâmetro, opcional inicializado com o valor false, utilizado para definir a linguagem retornada: inglês/português .<br />
   *
   * @param int $tipo_texto
   * Parâmetro, opcional inicializado com o valor 0 (aceita valores inteiros de 0 á 2, uma exceção será gerada se um valor inválido for inserido),
   * utilizado para definir 3 tipos de retorno da string se o parâmetro $retornar_texto for true:
   *
   * <ul>
   * 	<li>Se especificar o valor 0, o formato padrão, a primeira letra de cada palavra será maiúscula seguida por minúsculas, será retornado (ex. Vinte Cinco).</li>
   *    <li>1, o formato retornado será uma string minúscula.</li>
   *   	<li>2  uma string maiúscula será retornada.</li>
   * </ul>
   *
   *
   * <b>Exemplo de utilização da classe</b>   
   * <code>   
   * 		require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   * 		$obj_Bdata = new Base_Data();
   *
   * 		echo "Dia númerico: " . $obj_Bdata->getDia() . '.<br />';
   * 		echo "Dia textual em português: " . $obj_Bdata->getDia(true) . '.<br />';   
   * 		echo "Retorno em português e maiúsculo: " . $obj_Bdata->getDia(true, false, 2) . '.<br /><br />';
   *
   * 		echo "Chamada em inglês: " . $obj_Bdata->getDia(true, true) . '.<br />';
   * 		echo "Texto em inglês e minúsculo: " . $obj_Bdata->getDia(true, true, 1) . '.<br />';
   * </code>
   */

    public function getDia($retornar_texto = false, $is_english = false, $tipo_texto = 0)
    {
      #ini validacao
      if(!is_bool($retornar_texto))
	  throw new Exception('Primeiro parâmetro <b>$retornar_texto</b> inválido ! Aceito somente valores booleanos.');
	  
      else if(!is_bool($is_english))
	  throw new Exception('Segundo parâmetro <b>$is_english</b> inválido ! Aceito somente valores booleanos.');	

      else if(!is_int($tipo_texto))
	  throw new Exception('Terceiro parâmetro <b>$tipo_texto</b> inválido ! Aceito somente valores inteiros.');	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>3) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[1].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
	
       $this->Base_Data();

       if($retornar_texto)
       {
             $objValues = array();

             $objValues = $this->getFormats(3, $is_english);

             $index = $this->dia;

               switch($tipo_texto)
               {
                   case 0:
                               $this->dia = ucfirst($objValues[$index]);
                               break;

                   case 1:
                               $this->dia = strtolower($objValues[$index]);
                                break;

                   case 2:
                               $this->dia = strtoupper($objValues[$index]);
                               break;

                   default:
                               throw new Exception('Terceiro parâmetro <b>$tipo_texto</b> inválido ! Aceito somente os números  0, 1 e 2.');
                               break;
              }
	}

	   return $this->dia;
    }
    

  /**
   *
   * Método que retorna o mês em inteiro de dois dígitos, por extenso inglês/português e o ordinal.
   * @acess public
   * @name getMes
   * @return mixed
   *
   * @param bool $retornar_texto
   * Parâmetro, opcional inicializado com o valor false, utilizado para habilitar ou desabilitar o retorno como texto.<br /><br />
   *
   * @param bool $is_numeral
   * Parâmetro utilizado logicamente para determinar o tipo de retorno: numérico ordinal ou o mês.
   * 
   * <ul>
   *	<li>Se estiver com um valor true (verdadeiro) será retornado um valor numérico ordinal, por exemplo, "Primeiro" se o mês for "1";</li>
   *	<li>se estiver com um valor false será retornado por exemplo, "Fevereiro", se o mês for "2".</li>
   * </ul>
   *
   * @param bool $is_english
   * Parâmetro, opcional inicializado com o valor false, utilizado para definir a linguagem retornada: inglês/português .<br /><br />
   *
   * @param int $tipo_texto
   * Parâmetro, opcional inicializado com o valor 0 (aceita valores inteiros de 0 á 2, uma exceção será gerada se um valor inválido for inserido),
   * utilizado para definir 3 tipos de retorno da string se o parâmetro $retornar_texto for true.
   *
   * <ul>
   * 	<li>Se especificar o valor 0, o formato padrão, primeira letra de cada palavra em maiúscula seguida por minúsculas, será retornado (ex. Fevereiro);</li>
   *	<li>1, o formato retornado será uma string minúscula;</li>
   *	<li>2  uma string maiúscula será retornada.
   * </ul>
   *
   * <b>Exemplo de utilização da classe</b>
   * <code>
   *  require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   *  $obj_Bdata = new Base_Data();
   *
   *  echo "Mês númerico com dois dígitos: " . $obj_Bdata->getMes().'<br />';
   *  echo "Mês númerico com um dígito (usando cast): " .(int) $obj_Bdata->getMes().'<br /><br />';
   *
   *  echo "Estamos em " . $obj_Bdata->getMes(true).'.<br />';
   *  echo "Mês em minúsculo: ".$obj_Bdata->getMes(true, false, false, 1).'.<br />';
   *  echo "Mês em inglês: ". $obj_Bdata->getMes(true, false, true).'<br />';
   *  echo "Mês em inglês e maiúsculo: ". $obj_Bdata->getMes(true, false, true, 2).'<br /><br />';
   *
   *  echo "Estamos no <em>". $obj_Bdata->getMes(true, true).'</em> mês.<br />';
   *  echo "Ordinal em inglês: ". $obj_Bdata->getMes(true, true, true).'.<br />';
   *  echo "Ordinal em inglês e maiúsculo: ". $obj_Bdata->getMes(true, true, true, 2).'.<br />';
   * </code>
   */

    public function getMes($retornar_texto = false, $is_numeral = false, $is_english = false, $tipo_texto = 0)
    {
      #ini validacao
      if(!is_bool($retornar_texto))
	  throw new Exception('Primeiro parâmetro <b>$retornar_texto</b> inválido ! Aceito somente valores booleanos.');
	  
      else if(!is_bool($is_numeral))
	  throw new Exception('Segundo parâmetro <b>$is_numeral</b> inválido ! Aceito somente valores booleanos.');	
	  
      else if(!is_bool($is_english))
	  throw new Exception('Segundo parâmetro <b>$is_english</b> inválido ! Aceito somente valores booleanos.');		  

      else if(!is_int($tipo_texto))
	  throw new Exception('Terceiro parâmetro <b>$tipo_texto</b> inválido ! Aceito somente valores inteiros.');	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>4) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[2].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
       $this->Base_Data();

       if($retornar_texto)
       {
           $objValues = array();

           if(!$is_numeral)
           {
              //texto meses
              $objValues = $this->getFormats(1, $is_english);
           }
           else
                  {
                    //texto mês numeral ordinal
                     $objValues = $this->getFormats(2, $is_english);
                  }

        //cast usado para tirar o zero inicial do mês
        $index= (int) $this->mes;

        switch($tipo_texto)
        {
             case 0:
	      $this->mes = ucfirst($objValues[$index]);
             break;

            case 1:
	      $this->mes = strtolower($objValues[$index]);
             break;

             case 2:
	      $this->mes = strtoupper($objValues[$index]);
             break;

             default:
		    throw new Exception('Quarto parâmetro <b>$tipo_texto</b> inválido ! Aceito somente os números  0, 1 e 2.');
             break;
          }
       }

       return $this->mes;
    }

  /**
   * Método que retorna o ano em 2 ou 4 dígitos.
   * @acess public
   * @name getAno
   * @return int
   *
   *@param bool $is_4_digitos
   * Com o valor true retornará um ano com 4 digitos, caso contrário 2 dígitos.
   */
    public function getAno($is_4_digitos = true)
    {
      #ini validacao
      if(!is_bool($is_4_digitos))
	  throw new Exception('Primeiro parâmetro <b>$is_4_digitos</b> inválido ! Aceito somente valores booleanos.');	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[3].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
       if($is_4_digitos)
	return $this->ano;
	
       else
	return gmdate('y');
    }

  /**
   *
   * Método que retorna o dia da semana em inglês/português ou numérico de 1 (Domingo) à 7 (Sábado).
   * @acess public
   * @name getDiaDaSemana
   * @return mixed
   *
   * @param bool $retornar_texto
   * Parâmetro, opcional inicializado com o valor false, utilizado para habilitar ou desabilitar o retorno como texto.<br /><br />
   *
   * @param bool $is_numeral
   * Parâmetro utilizado logicamente para determinar o tipo de retorno: numérico ordinal ou o dia da semana. Se estiver com um valor true (verdadeiro) será retornado um valor numérico ordinal, por exemplo, "Primeiro" se o dia da semana for "1"; se estiver com um valor false será retornado por exemplo, "Domingo", se o dia da semana for "1".<br /><br />
   *
   * @param bool $is_english
   * Parâmetro, opcional inicializado com o valor false, utilizado para definir a linguagem retornada: inglês/português .<br /><br />
   *
   * @param int $tipo_texto
   * Parâmetro, opcional inicializado com o valor 0 (aceita valores inteiros de 0 á 2, uma exceção será gerada se um valor inválido for inserido), utilizado para definir 3 tipos de retorno da string se o parâmetro $retornar_texto for true.<br />
   *  Se especificar o valor 0, o formato padrão, primeira letra de cada palavra em maiúscula seguida por minúsculas, será retornado (ex. Segunda-Feira). Se especificar 1, o formato retornado será uma string minúscula, e se especificar 2  uma string maiúscula será retornada.<br /><br />
   *
   *
   * <b>Exemplo de utilização da classe</b>
   * <code>
   *  require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   *  $obj_Bdata = new Base_Data();
   *
   *  echo "Dia númerico: " . $obj_Bdata->getDiaDaSemana() . '.<br />';
   *  echo "Dia númerico em português: " . $obj_Bdata->getDiaDaSemana(true) . '.<br />';
   *
   *  echo "Dia númerico em inglês: " . $obj_Bdata->getDiaDaSemana(true,true,true) . '.<br />';
   *  echo "Dia númerico em inglês e maiúsculo: " . $obj_Bdata->getDiaDaSemana(true,true,true, 2) . '.<br /><br />';
   *  echo "Dia da semana em português: " . $obj_Bdata->getDiaDaSemana(true,false) . '.<br />';
   *
   *  echo "Dia da semana em inglês: " . $obj_Bdata->getDiaDaSemana(true,false,true) . '.<br />';
   *  echo "Dia da semana em inglês e minúsculo: " . $obj_Bdata->getDiaDaSemana(true,false,true,1) . '.<br />';
   * </code>
   */
   public function getDiaDaSemana($retornar_texto = false, $is_numeral = true, $is_english = false, $tipo_texto = 0)
   {
      #ini validacao
      if(!is_bool($retornar_texto))
	  throw new Exception('Primeiro parâmetro <b>$retornar_texto</b> inválido ! Aceito somente valores booleanos.');
	  
      else if(!is_bool($is_numeral))
	  throw new Exception('Segundo parâmetro <b>$is_numeral</b> inválido ! Aceito somente valores booleanos.');	
	  
      else if(!is_bool($is_english))
	  throw new Exception('Segundo parâmetro <b>$is_english</b> inválido ! Aceito somente valores booleanos.');		  

      else if(!is_int($tipo_texto))
	  throw new Exception('Terceiro parâmetro <b>$tipo_texto</b> inválido ! Aceito somente valores inteiros.');	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>4) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[4].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
       $this->Base_Data();

       if($retornar_texto)
       {
           $objValues = array();

            if($is_numeral)
            {
               //texto numeral
               $objValues = $this->getFormats(2, $is_english);
            }
             else
                   {
                      //texto semana
                      $objValues = $this->getFormats(0, $is_english);
                    }

		if(empty($objValues[0]))
		{
		  $index = $this->dia_da_semana + 1;
		}
		else
		  {
			//dia que inicia no 0
			$index = $this->dia_da_semana;
		  }

	   switch($tipo_texto)
	   {
		   case 0:
			    $this->dia_da_semana = ucfirst($objValues[$index]);
			    break;

		   case 1:
			    $this->dia_da_semana = strtolower($objValues[$index]);
			    break;

		   case 2:
			    $this->dia_da_semana = strtoupper($objValues[$index]);
			    break;

		  default:
			    throw new Exception('Quarto parâmetro <b>$tipo_texto</b> inválido ! Aceito somente os números  0, 1 e 2.');
			    break;
	   }
     }
     else $this->dia_da_semana = ($this->dia_da_semana + 1);

     return $this->dia_da_semana;
   }


  /**
   * Método que retorna o dia do ano, começando do 0, e também quantos dias faltam para acabar o ano.
   *
   * @param bool $quantos_fim
   * Com o valor true, será retornado quantos dias faltam para acabar o ano.
   * @acess public
   * @name getDiaDoAno
   * @return int
   *
   * <b>Exemplo de utilização da classe</b>
   *
   * <code>
   *  require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   *  $obj_Bdata = new Base_Data();
   *
   *  echo "Já se passou ".$obj_Bdata->getDiaDoAno().' dias desde que começou o ano de ' .$obj_Bdata->getAno() .'.<br />';
   *  echo "Faltam ".$obj_Bdata->getDiaDoAno(true). ' dias para acabar o ano.';
   * </code>
   */
   public function getDiaDoAno($quantos_fim = false)
   {
      if(!is_bool($quantos_fim))
	 throw new Exception('Primeiro parâmetro <b>$quantos_fim</b> inválido ! Aceito somente valores booleanos.');

	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[5].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
	
      if($this->getAnoBissexto())
	$dias = 366;
      else
	$dias = 365;

      if($quantos_fim)
	  $this->dia_do_ano = ($dias - $this->dia_do_ano);

      return $this->dia_do_ano;
   }

  /**
   * Método que retorna 1 se está em ano bissexto, 0 caso contrário.
   * @acess public
   * @name getAnoBissexto
   * @return int
   *
   * <b>Exemplo de utilização da classe</b>
   *
   * <code>
   *  require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   *  $obj_Bdata1 = new Base_Data();
   *
   *  if($obj_Bdata1->getAnoBissexto())$value = "é"; else $value = "não é";
   *  echo "Este $value um ano bissexto.";
   * </code>
   */
   public function getAnoBissexto()
   {
	$numargs = func_num_args();
	
	if($numargs>0) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[6].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
	
       return $this->ano_bissexto;
   }

  /**
   * Método que retorna a quantidade de dias do mês atual, o dia atual e quantos dias faltam para acabar o mês.
   *
   * @param bool $cont
   *  Se iniciado com o valor true habilitará a contagem dos dias para o segundo parâmetro.
   *
   * @param bool $falta
   * Caso true, retornará os dias que faltam para terminar o mês, caso contrário, retornará o dia atual.
   *
   * @acess public
   * @name getDiasDesteMes
   * @return int
   *
   * Exemplo de utilização da classe
   *
   * <code>
   *  require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.base.data.php');   
   *  $obj_Bdata = new Base_Data();
   *
   *  echo "Este mês [<small>".$obj_Bdata->getMes()."</small>] tem ". $obj_Bdata->getDiasDesteMes().' dias.<br />';
   *  echo "E já se passaram ". $obj_Bdata->getDiasDesteMes(true).' dias.<br />';
   *  echo "Faltam ". $obj_Bdata->getDiasDesteMes(true,true).' dias para terminar o mês.<br />';
   * </code>
   */

   public function getDiasDesteMes($cont = false, $falta = false)
   {
   #$this->Base_Data();
      #ini validacao
      if(!is_bool($cont))
	  throw new Exception('Primeiro parâmetro <b>$cont</b> inválido ! Aceito somente valores booleanos.');
	  
      else if(!is_bool($falta))
	  throw new Exception('Segundo parâmetro <b>$falta</b> inválido ! Aceito somente valores booleanos.');	
	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>2) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[7].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
      $dia_result=0;
      
      if($cont)
      {
          if($falta)
	    $dia_result = ($this->dias_deste_mes - $this->dia);
	    
          else
	    $dia_result = $this->dia;
      }
      else $dia_result = $this->dias_deste_mes;

      return $dia_result;
   }

  /**
   * Método que retorna um array associado ao primeiro parâmetro.
   *
   * @param bool $tipo_retorno
   * Aceita somente valores de 0 á 3 (valores fora dos limites uma exceção será lançada).<br /><br />
   * Especificando o valor 0, será retornado os dias da semana (ex. "Segunda-Feira").<br />
   * Especificando o valor 1, será retornado os meses do ano (ex. "Janeiro").<br />
   * Especificando o valor 2, será retornado os números ordinais de 1 á 7 (ex. "Primeiro").<br />
   * Especificando o valor 3, será retornado os dias de 1 até 31 por extenso (ex. "trinta").<br /><br />
   *
   * @param bool $is_english
   *  Habilita/desabilita o retorno na língua inglesa.
   *
   * @acess private
   * @name getFormats
   * @return array
   *
   */
  private function getFormats($tipo_retorno = 0, $is_english = false)
  {
      #ini validacao
      if(!is_int($tipo_retorno))
	  throw new Exception('Primeiro parâmetro <b>$tipo_retorno</b> inválido ! Aceito somente valores inteiros.');
	  
      else if(!is_bool($is_english))
	  throw new Exception('Segundo parâmetro <b>$is_english</b> inválido ! Aceito somente valores booleanos.');	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>3) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[8].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
	  
     switch($tipo_retorno)
     {
        case 0:
                    if($is_english)
                    {
                         $array_DSemana_en_us = array();
                         $array_DSemana_en_us[0] = "Sunday";
                         $array_DSemana_en_us[1] = "Monday";
                         $array_DSemana_en_us[2] = "Tuesday";
                         $array_DSemana_en_us[3] = "Wednesday";
                         $array_DSemana_en_us[4] = "Thursday";
                         $array_DSemana_en_us[5] = "Friday";
                         $array_DSemana_en_us[6] = "Saturday";

                         $objValues = $array_DSemana_en_us;
                     }
                     else
                            {
                                $array_DSemana_pt_br = array();
                                $array_DSemana_pt_br[0] = "Domingo";
                                $array_DSemana_pt_br[1] = "Segunda-Feira";
                                $array_DSemana_pt_br[2] = "Terça-Feira";
                                $array_DSemana_pt_br[3] = "Quarta-Feira";
                                $array_DSemana_pt_br[4] = "Quinta-Feira";
                                $array_DSemana_pt_br[5] = "Sexta-Feira";
                                $array_DSemana_pt_br[6] = "Sábado";

                                $objValues = $array_DSemana_pt_br;
                            }
        break;

        case 1:
                    if($is_english)
                    {
                       $array_enUS_Mes = Array();
                       $array_enUS_Mes[1] = "january";
                       $array_enUS_Mes[2] = "february";
                       $array_enUS_Mes[3] = "march";
                       $array_enUS_Mes[4] = "april";
                       $array_enUS_Mes[5] = "may";
                       $array_enUS_Mes[6] = "june";
                       $array_enUS_Mes[7] = "july";
                       $array_enUS_Mes[8] = "august";
                       $array_enUS_Mes[9] = "september";
                       $array_enUS_Mes[10] = "october";
                       $array_enUS_Mes[11] = "november";
                       $array_enUS_Mes[12] = "december";

                       $objValues = $array_enUS_Mes;
                     }
                     else
                        {
                          $array_ptBR_Mes = Array();
                          $array_ptBR_Mes[1] = "janeiro";
                          $array_ptBR_Mes[2] = "fevereiro";
                          $array_ptBR_Mes[3] = "março";
                          $array_ptBR_Mes[4] = "abril";
                          $array_ptBR_Mes[5] = "maio";
                          $array_ptBR_Mes[6] = "junho";
                          $array_ptBR_Mes[7] = "julho";
                          $array_ptBR_Mes[8] = "agosto";
                          $array_ptBR_Mes[9] = "setembro";
                          $array_ptBR_Mes[10] = "outubro";
                          $array_ptBR_Mes[11] = "novembro";
                          $array_ptBR_Mes[12] = "dezembro";

                          $objValues = $array_ptBR_Mes;
                       }
        break;

        case 2:
                     if($is_english)
                     {
                         $array_enUS_MesNumeral = Array();
                         $array_enUS_MesNumeral[1] = "first";
                         $array_enUS_MesNumeral[2] = "second";
                         $array_enUS_MesNumeral[3] = "third";
                         $array_enUS_MesNumeral[4] = "fourth";
                         $array_enUS_MesNumeral[5] = "fifth";
                         $array_enUS_MesNumeral[6] = "sixth";
                         $array_enUS_MesNumeral[7] = "seventh";
                         $array_enUS_MesNumeral[8] = "eighth";
                         $array_enUS_MesNumeral[9] = "ninth";
                         $array_enUS_MesNumeral[10] = "tenth";
                         $array_enUS_MesNumeral[11] = "eleventh";
                         $array_enUS_MesNumeral[12] = "twelfth";

                         $objValues = $array_enUS_MesNumeral;
                     }
                     else
                           {
                                 $array_ptBR_MesNumeral = Array();
                                 $array_ptBR_MesNumeral[1] = "primeiro";
                                 $array_ptBR_MesNumeral[2] = "segundo";
                                 $array_ptBR_MesNumeral[3] = "terceiro";
                                 $array_ptBR_MesNumeral[4] = "quarto";
                                 $array_ptBR_MesNumeral[5] = "quinto";
                                 $array_ptBR_MesNumeral[6] = "sexto";
                                 $array_ptBR_MesNumeral[7] = "sétimo";
                                 $array_ptBR_MesNumeral[8] = "oitavo";
                                 $array_ptBR_MesNumeral[9] = "nono";
                                 $array_ptBR_MesNumeral[10] = "décimo";
                                 $array_ptBR_MesNumeral[11] = "décimo primeiro";
                                 $array_ptBR_MesNumeral[12] = "décimo segundo";

                                 $objValues = $array_ptBR_MesNumeral;
                            }
        break;

        case 3:
                    if(!$is_english)
                   {
                      $array_ptBR_text = array();
                      $array_ptBR_text[1] = "um";
                      $array_ptBR_text[2] = "dois";
                      $array_ptBR_text[3] = "tres";
                      $array_ptBR_text[4] = "quatro";
                      $array_ptBR_text[5] = "cinco";
                      $array_ptBR_text[6] = "seis";
                      $array_ptBR_text[7] = "sete";
                      $array_ptBR_text[8] = "oito";
                      $array_ptBR_text[9] = "nove";
                      $array_ptBR_text[10] = "dez";

                      $array_ptBR_text[11] = "onze";
                      $array_ptBR_text[12] = "doze";
                      $array_ptBR_text[13] = "treze";
                      $array_ptBR_text[14] = "catorze";
                      $array_ptBR_text[15] = "quinze";
                      $array_ptBR_text[16] = "dezesseis";
                      $array_ptBR_text[17] = "dezessete";
                      $array_ptBR_text[18] = "dezoito";
                      $array_ptBR_text[19] = "dezenove";
                      $array_ptBR_text[20] = "vinte";

                      $array_ptBR_text[21] = "vinte um";
                      $array_ptBR_text[22] = "vinte dois";
                      $array_ptBR_text[23] = "vinte três";
                      $array_ptBR_text[24] = "vinte quatro";
                      $array_ptBR_text[25] = "vinte cinco";
                      $array_ptBR_text[26] = "vinte seis";
                      $array_ptBR_text[27] = "vinte sete";
                      $array_ptBR_text[28] = "vinte oito";
                      $array_ptBR_text[29] = "vinte nove";
                      $array_ptBR_text[30] = "trinta";

                      $array_ptBR_text[31] = "trinta e um";

                    $objValues = $array_ptBR_text;
                }
                else
                      {
                       $array_enUS_text = array();
                       $array_enUS_text[1] = "one";
                       $array_enUS_text[2] = "two";
                       $array_enUS_text[3] = "three";
                       $array_enUS_text[4] = "four";
                       $array_enUS_text[5] = "five";
                       $array_enUS_text[6] = "six";
                       $array_enUS_text[7] = "seven";
                       $array_enUS_text[8] = "eight";
                       $array_enUS_text[9] = "nine";
                       $array_enUS_text[10] = "ten";

                       $array_enUS_text[11] = "eleven";
                       $array_enUS_text[12] = "twelve";
                       $array_enUS_text[13] = "thirteen";
                       $array_enUS_text[14] = "fourteen";
                       $array_enUS_text[15] = "fifteen";
                       $array_enUS_text[16] = "sixteen";
                       $array_enUS_text[17] = "seventeen";
                       $array_enUS_text[18] = "eighteen";
                       $array_enUS_text[19] = "nineteen";
                       $array_enUS_text[20] = "twenty";

                       $array_enUS_text[21] = "twenty one";
                       $array_enUS_text[22] = "twenty two";
                       $array_enUS_text[23] = "twenty three";
                       $array_enUS_text[24] = "twenty four";
                       $array_enUS_text[25] = "twenty five";
                       $array_enUS_text[26] = "twenty six";
                       $array_enUS_text[27] = "twenty seven";
                       $array_enUS_text[28] = "twenty eight";
                       $array_enUS_text[29] = "twenty nine";
                       $array_enUS_text[30] = "thirty";

                       $array_enUS_text[31] = "thirty one";

                      $objValues = $array_enUS_text;
                    }
       break;

         default:
                 throw new Exception('Primeiro parâmetro <b>$tipo_retorno</b> inválido ! Range fora dos limites.');	
                 break;
       }

       return $objValues;
   }
}
?>