<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.3 - 19/09/2013 20:05
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://br2.php.net/manual/pt_BR/function.date.php
 * @link http://fsf.fabianosantos.net/index.php?action=package
 * @since 0.1
 * @package Tempo
 * @subpackage Datas
 */

/** 
 * Classe usada para retornar variações de datas entre o português e inglês.
 */

class Data_Formats
{
  /**
   * Propriedade que armazena o dia.
   * @property int $dia
   */

    private $dia;

  /**
   * Propriedade que armazena o mês.
   * @property int $mes
   */

    private $mes;

  /**
   * Propriedade que armazena o ano.
   * @property int $ano
   */

    private $ano;

  /**
   * Construtor inicializador das propriedades privadas referente a data.
   * @name Data_Formats
   * @acess public
   *
   * @param string $setTimeZone
   * Define o timezone para a data.
   */

    public function Data_Formats($setTimeZone='Europe/London')
    {
      #ini validacao
      if(!is_string($setTimeZone))
	  throw new Exception('Primeiro parâmetro <b>$setTimeZone</b> inválido ! Aceito somente strings.');	  	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no Contrutor da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
    
      #set Default Timezone      
      if(!@date_default_timezone_set($setTimeZone)) 
	throw new Exception('String de TimeZone Inválido para o parâmetro <b>$setTimeZone</b> ! Para uma lista válida de argumentos acesse: <a href="http://php.net/manual/en/function.date-default-timezone-set.php" target="_blank">http://php.net/manual/en/function.date-default-timezone-set.php</a>.');
          
      $this->dia = (int) gmdate('d');
      $this->mes = (int) gmdate('m');
      $this->ano = (int) gmdate('Y');
    }

  /**
   * Método utilizado internamente para formatar a saída de uma determinada data.<br />
   * A string retornada pode ter uma saída tanto no padrão inglês quanto no português.
   *
   * @acess private
   * @name Format   
   * @return string
   *
   * @param string $paramDia
   * Armazena o dia.
   *
   * @param string $paramMes
   * Armazena o mês.
   *
   * @param string $paramAno
   * Armazena o ano.
   * 
   * @param int $paramEstilo
   * O parâmetro $paramEstilo determina o tipo de formatação da data.<br />
   * Note que para este método o quarto argumento, no caso, $paramEstilo, é opcional.<br />
   * Não especificando o quarto argumento o valor default de $paramEstilo é 1, isso significa que a saída terá o seguinte formato: 31/03/2009.<br />
   * É um método utilizado em {@link getDataFormatada()}
   *
   * @see getDataFormatada
   */

   private function Format($paramDia, $paramMes, $paramAno, $paramEstilo=1)
   {               
      #ini validacao
      if(!is_int($paramDia))
	  throw new Exception('Primeiro parâmetro <b>$paramDia</b> inválido ! Aceito somente valores inteiros.');
	  
      else if(!is_int($paramMes))
	  throw new Exception('Segundo parâmetro <b>$paramMes</b> inválido ! Aceito somente valores inteiros.');	

      else if(!is_int($paramAno))
	  throw new Exception('Terceiro parâmetro <b>$paramAno</b> inválido ! Aceito somente valores inteiros.');	
	  
      else if(!is_int($paramEstilo))
	  throw new Exception('Terceiro parâmetro <b>$paramEstilo</b> inválido ! Aceito somente valores inteiros.');		  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>4) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[1].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
        switch($paramEstilo)
        {
           case 1:
		      $fdata = $paramDia .'/'. $paramMes.'/'.$paramAno;
		      break;

           case 2:
		      $fdata = $paramMes.'/'.$paramDia.'/'.$paramAno;
		      break;

           case 3:
		      $fdata = $paramDia .'-'. $paramMes.'-'.$paramAno;
		      break;

           case 4:
		      $fdata = $paramMes.'-'.$paramDia.'-'.$paramAno;
		      break;

           case 5:
		      $fdata = $paramMes.$paramDia.$paramAno;
		      break;

           default:
		      throw new Exception('Quarto parâmetro <b>$paramEstilo</b> inválido ! Fora dos limites.');		  
		      break;
         }      
             
       return $fdata;
   }


  /**
   * Método que retorna a data no formato 31082009.
   * @access public 
   * @name getData
   * @return string
   */

     public function getData()
     {
        #ini validacao
      	$numargs = func_num_args();
	
	if($numargs>0) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[2].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      #fim validacao
      
        return gmdate('dmY');
     }

  /**
   * Método que retorna uma data formatada de acordo com o parâmetro $estilo.
   * @access public
   * @name getDataFormatada
   * @return string
   *
   * @param int $estilo
   * Os valores permitidos para este parâmetro são inteiros entre 1 e 5.<br />
   * Para o valor 1 a saída terá o seguinte formato: 31/03/2009.<br />
   * Para o valor 2 a saída terá o seguinte formato: 03/31/2009.<br />
   * Para o valor 3 a saída terá o seguinte formato: 31-03-2009.<br />
   * Para o valor 4 a saída terá o seguinte formato: 03-31-2009.<br />
   * Para o valor 5 a saída terá o seguinte formato: 03312009.<br /><br />
   *
   * Um valor diferente do especificado acima, irá gerar uma exceção.<br />
   * Para retornar uma saída 31032009, utilize o método {@link getData()}.
   *
   * <b>Exemplo de utilização da classe</b>
   *      
   * <code>      
   *    require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Datas/class.data_formats.php');      
   *    $data_f = new Data_Formats();
   *
   *    echo $data_f->getDataFormatada(1).'<br / >';
   *    echo $data_f->getDataFormatada(2).'<br / >';
   *    echo $data_f->getData();
   * </code>     
   *
   * @see Base_Data
   */

     public function getDataFormatada($estilo)
     {
	#ini validacao
	if(!is_int($estilo))
	    throw new Exception('Primeiro parâmetro <b>$estilo</b> inválido ! Aceito somente valores inteiros.');	
	else 
	{
	  $numargs = func_num_args();
	  
	  if($numargs>1) 
	  {
	    $c=get_class_methods($this);
	    
	    throw new Exception('<b>Erro no método '.$c[3].'() da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	  }
	}
	#fim validacao
       return $this->Format($this->dia, $this->mes, $this->ano, $estilo);
     }  
}
?>