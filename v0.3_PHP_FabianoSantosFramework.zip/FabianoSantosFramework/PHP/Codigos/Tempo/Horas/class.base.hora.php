<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.3 - 23/09/2013 01:20
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://br2.php.net/manual/pt_BR/function.date.php
 * @link http://fsf.fabianosantos.net/index.php?action=package
 * @since 0.1
 * @package Tempo
 * @subpackage Horas
 */

/**
 * Classe base utilizada para retornar todas as partes que compõem uma determinada hora, sendo esta no formato de 01 à 12 ou 00 à 23, utilizando métodos fáceis de usar.
 */

class Base_Hora
{

/**
 * Propriedade que armazena a hora definida pelo construtor.
 * @access private
 * @property int $hora
 */

  private $hora;

/**
 * Propriedade que armazena o minuto definida pelo construtor.
 * @access private
 * @property int $minuto
 */

  private $minuto;

/**
 * Propriedade que armazena o segundo definida pelo construtor.
 * @access private
 * @property int $segundo
 */

  private $segundo;

/**
 * Propriedade que armazena a string am/pm ou AM/PM ao qual se refere às horas no formato de 01 à 12.
 * @access private
 * @property string $ampm
 */

  private $ampm;


/**
 * Propriedade que armazena se está ou não no horário de verão.
 * @access private
 * @property int $is_horario_de_verao
 */

  private $is_horario_de_verao;

/**
 * Construtor inicializador das propriedades referente a {@link $hora}, {@link $minuto}, {@link $segundo} e {@link $ampm}.
 * @access public
 * @name Base_Hora()
 *
 * @param bool $hora_full
 * Este é um parâmetro opcional, inicializado com false, utilizado para definir o tipo de formato da hora: de 01 à 12 ou 00 à 23.
 * A propriedade {@link $ampm} não será inicializada se o parâmetro {@link $hora_full} for verdadeiro.
 */

   public function Base_Hora($hora_full = false)
   {     
        #ini validacao
      if(!is_bool($hora_full))
	  throw new Exception('Primeiro parâmetro <b>$hora_full</b> inválido ! Aceito somente valores booleanos.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no contrutor da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
     if($hora_full)
      $this->hora = gmdate('H');        
     else
      {
	$this->hora = gmdate('h');             
	$this->ampm = gmdate('a');
      }
     
      $this->minuto = gmdate('i');
      $this->segundo = gmdate('s');
      $this->is_horario_de_verao = gmdate('I');
   }

/**
 * Método que retorna a hora referente ao GMT 00:00 de Greenwich. O formato de retorno da hora depende do parâmetro {@link $hora_full} especificado no construtor.
 * 
 * <b>Exemplo 01 de utilização da classe</b> 
 * 
 * <code> 
 * require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Horas/class.base.hora.php'); 
 * $tempo = new Base_Hora(true);
 *
 * echo $tempo->getHora().':';
 * echo $tempo->getMinuto().':';
 * echo $tempo->getSegundo();
 * </code>
 *     
 * <b>Exemplo 02 de utilização da classe</b>
 *     
 * <code>
 * $tempo2 = new Base_Hora();
 * echo $tempo2->getHora().':';
 *
 * echo $tempo2->getMinuto().':';
 * echo $tempo2->getSegundo();
 * echo $tempo2->getAmPm(); 
 * </code>
 * 
 * @name getHora
 * @access public
 * @return int
 */

   public function getHora()
   {
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[1].' da classe '.$c[0].':</b> <em>Este método não possui parâmetros !</em>');	
    }
	
     return $this->hora; 
   }

/**
 * Método que retorna o minuto referente ao GMT 00:00 de Greenwich.
 * @name getMinuto
 * @return int
 * @access public
 */

   public function getMinuto()
   {
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[2].' da classe '.$c[0].':</b> <em>Este método não possui parâmetros !</em>');	
    }  
   
     return $this->minuto; 
   }

/**
 * Método que retorna o segundo referente ao GMT 00:00 de Greenwich.
 * @name getSegundo
 * @return int
 * @access public
 */

   public function getSegundo()
   {
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[3].' da classe '.$c[0].':</b> <em>Este método não possui parâmetros !</em>');	
    }
   
     return $this->segundo; 
   }

/**
 * Método que retorna a string AM/PM ou am/pm referente ao formato de hora de 01 à 12. Este método lançará uma exceção se o parâmetro {@link $hora_full} estiver definido como true.
 * @name getAmPm
 * @return string
 * @access public
 *
 * @param bool $isMaiuscula
 *  Parâmetro opcional, inicializado com o valor false, utilizado para retornar a string em maiúscula ou minúscula.
 */

   public function getAmPm($isMaiuscula = false)
   {
      #ini validacao
      if(!is_bool($isMaiuscula))
	  throw new Exception('Primeiro parâmetro <b>$isMaiuscula</b> inválido ! Aceito somente valores booleanos.');	  	
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[4].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao

    
     if(!gettype($this->ampm) == 'null' || !empty($this->ampm))
     {
         if(!$isMaiuscula) return $this->ampm;
         else return strtoupper($this->ampm);
      }
      else
            {
              throw new Exception("Chamada para o método <em>getAmPm()</em> inválida ! Formato de horas incompatível !");
            }
   }

/**
 * Método que retorna 1 se estiver no horário de verão e 0 se não.
 * @name getIsHorarioDeVerao
 * @return int
 * @access public
 */
   public function getIsHorarioDeVerao()
   {
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[5].' da classe '.$c[0].':</b> <em>Este método não possui parâmetros !</em>');	
    }
   
      return $this->is_horario_de_verao;
   }
}
?>