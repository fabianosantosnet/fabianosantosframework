<?php

/**
 * @author Fabiano Santos <fabiano@fabianosantos.net>
 * @version 0.3 - 24/09/2013 01:50
 * @copyright © 2013, Fabiano Santos.
 * @license http://fsf.fabianosantos.net/index.php?action=licence Licença de Código
 * @see http://br2.php.net/manual/pt_BR/function.date.php
 * @link http://fsf.fabianosantos.net/index.php?action=package
 * @since 0.1
 * @package Tempo
 * @subpackage Horas
 */

/**
 * Código adicional indispensável para esta classe.
 */
  
   require('class.base.hora.php');

/**
 * Classe usada para retornar a hora de acordo com o horário GMT especificado. O tipo de hora pode ser do formato de 01 à 12 ou de 00 à 23.
 */

class Hora_GMT extends Base_Hora
{

/**
 * Propriedade que armazena a string AM/PM ou am/pm
 * @property string $ampm
 */

   private $ampm;

/**
 * Propriedade que armazena a hora atual definida pelo construtor e métodos internos.
 * @property int $hora
 */

   private $hora;

/**
 * Propriedade booleana que define o conteúdo da propriedade $ampm como maiúscula/minúscula.
 * @property bool $is_ampm_maiusculo
 */

   private $is_ampm_maiusculo;

/**
 * Propriedade booleana setada no primeiro parâmetro do construtor, que indica se a hora está no intervalo de 00 à 23 ou de 01 à 12.
 * @property bool $is_hora_full
 */

   private $is_hora_full;

/**
 * Propriedade inteira criada para atualizar o am/pm ou AM/PM referente a definição de horas 12 e -12.
 * @property int $update_ampm
 */

   private $update_ampm;

/**
 * Este construtor chama o construtor base e define os valores das propriedades privadas {@link $is_hora_full}, {@link $is_ampm_maiusculo}, {@link $hora e $ampm} e
 * {@link $update_ampm}.
 * As propriedades {@link $hora} e {@link $ampm} são inicializadas por métodos da classe base.
 * Este construtor aceita dois parâmetros opcionais e estes parâmetros estão pré-inicializados com o valor false.
 * @name Hora_GMT
 * 
 * @param bool $is_hora_full
 * Este parâmetro inicializa a propriedade da classe {@link $is_hora_full}; caso esteja definido como true, não chama o método da classe base,
 * que define a propriedade {@link $ampm}.<br /><br />
 *
 * @param bool $is_ampm_maiusculo
 * Este parâmetro inicializa a propriedade da classe {@link $is_ampm_maiusculo}, se o valor do primeiro parâmetro for false.
 */
   
   public function Hora_GMT($is_hora_full = false, $is_ampm_maiusculo = false)
   {
      #ini validacao
      if(!is_bool($is_hora_full))
	  throw new Exception('Primeiro parâmetro <b>$is_hora_full</b> inválido ! Aceito somente valores booleanos.');
	  
      else if(!is_bool($is_ampm_maiusculo))
	  throw new Exception('Segundo parâmetro <b>$is_ampm_maiusculo</b> inválido ! Aceito somente valores booleanos.');	  		  
	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>2) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no Contrutor da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }     
 
      #fim validacao

     $this->is_hora_full = $is_hora_full;
     $this->Base_Hora($this->is_hora_full);
     $this->hora = $this->getHora();
     $this->update_ampm = 0;

     if(!$this->is_hora_full)
     {
         $this->is_ampm_maiusculo = $is_ampm_maiusculo;
         $this->ampm = $this->getAmPm($this->is_ampm_maiusculo);
      }
   }
   
/**
 * Este método define a hora através do parâmetro $intGMT.
 * @name defineGMT
 * @return void
 *
 * @param int $intGMT
 * Este parâmetro aceita valores inteiros de -12 á +12;  para um valor diferente, será lançada uma exceção.
 */
  
   public function defineGMT($intGMT)
   {
     #ini validacao
      if(!is_int($intGMT))
	  throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Aceito somente valores inteiros.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[1].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao
      
      if($intGMT < -12)
      throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Número fora dos limites GMT-12 à GMT +12 !');

      else if($intGMT > 12)
      throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Número fora dos limites GMT-12 à GMT +12 !');

      
      if($this->is_hora_full)
      {
          if($intGMT >= 0)
          {
             $this->gmtPositivo24H($intGMT);
          }
          else
                { 
                   $this->gmtNegativo24H($intGMT);
                }
      }
      else
            {
		  /* 12/02/2012 arrumado a atualização AM/PM para horas no formato de 12 horas */
		  if($intGMT==-12) $this->update_ampm = 1;

                   if($intGMT >= 0)
                  {
                     $this->gmtPositivo12H($intGMT);
                  }
                   else
                         {         
                             $this->gmtNegativo12H($intGMT);                 
                         }
            }
   }


 /**
  * Método utilizado pelos métodos  {@link gmtPositivo12H} e  {@link gmtNegativo12H} para mudar o valor da propriedade {@link $ampm} de acordo com a hora definida
  * pelo parâmetro $intGMT do método  {@link defineGMT}.
  * Esse método é utilizado somente quando a propriedade {@link $is_hora_full} é definida como false.
  * @name defineAmPm
  * @access private
  * @return void
  */

   private function defineAmPm()
  {	
    #ini validacao      
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[2].' da classe '.$c[0].':</b> <em>Nenhum argumento implementado !</em>');	
    }      
    #fim validacao  
      
     $tipo_str = $this->getAmPm($this->is_ampm_maiusculo);

      if($tipo_str == 'am')
     {
         $this->ampm = 'pm';
      }
      else if($tipo_str == 'AM')
     {
         $this->ampm = 'PM';        
      }
      else if($tipo_str == 'pm')
     {
         $this->ampm = 'am';
      }
      else if($tipo_str == 'PM')
     {
         $this->ampm = 'AM';
      }
   }

 /**
  * Este método define a hora com base em inteiros positivos de 0 á 12, e é utilizado somente quando a propriedade  {@link $is_hora_full} é definida como false.
  * É chamado pelo método  {@link defineGMT}.
  * @name gmtPositivo12H
  * @access private
  * @return void
  * 
  * @param int $intGMT
  * Redefine os valores das propriedades {@link $hora} e {@link $ampm}.
  */

  private function gmtPositivo12H($intGMT)
  {    
     #ini validacao
      if(!is_int($intGMT))
	  throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Aceito somente valores inteiros.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[3].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao  
      
      switch($intGMT)
      {
        case 1:
                    if($this->hora == 11)
                     {
                         $this->hora = 12;
                         $this->defineAmPm();
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 1;
                     }
                     else 
                     {                       
                       $this->hora = ($this->hora + 1);
                     }
                     break;

        case 2:
                    if($this->hora == 10)
                     {
                        $this->defineAmPm();
                        $this->hora = 12;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 2;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 2);
                     }
                     break;

        case 3:
                   if($this->hora == 9)
                     {
                        $this->defineAmPm();
                        $this->hora = 12;
                     }
                   else if($this->hora == 10)
                     {
                        $this->defineAmPm();
                        $this->hora = 1;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 3;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 3);
                     }
                     break;

        case 4:
                     if($this->hora == 8)
                     {
                        $this->defineAmPm();
                        $this->hora = 12;
                     }
                   else if($this->hora == 9)
                     {
                        $this->defineAmPm();
                        $this->hora = 1;
                     }
                   else if($this->hora == 10)
                     {
                        $this->defineAmPm();
                        $this->hora = 2;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 4;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 4);
                     }
                     break;

        case 5:
                    if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 5;
                     }
                     else 
                     {
                       $this->hora = ($this->hora +  5);
                     }
                     break;

        case 6:
                    if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 6;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 6);
                     }
                     break;

        case 7:
                    if($this->hora == 5)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 6;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 7;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 7);
                     }
                     break;

        case 8:
                    if($this->hora == 4)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 5)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 6;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 7;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 8;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 8);
                     }
                     break;

        case 9:
                    if($this->hora == 3)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 4)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 5)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 6;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 7;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 8;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 9;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 9);
                     }
                     break;

        case 10:
                    if($this->hora == 2)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 3)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 4)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 5)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 6;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 7;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 8;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 9;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 10;
                     }
                    else 
                     {
                       $this->hora = ($this->hora + 10);
                     }
                     break;

        case 11:
                    if($this->hora == 1)
                     {
                         $this->defineAmPm();
                         $this->hora = 12;
                     }
                    else if($this->hora == 2)
                     {
                         $this->defineAmPm();
                         $this->hora = 1;
                     }
                    else if($this->hora == 3)
                     {
                         $this->defineAmPm();
                         $this->hora = 2;
                     }
                    else if($this->hora == 4)
                     {
                         $this->defineAmPm();
                         $this->hora = 3;
                     }
                    else if($this->hora == 5)
                     {
                         $this->defineAmPm();
                         $this->hora = 4;
                     }
                    else if($this->hora == 6)
                     {
                         $this->defineAmPm();
                         $this->hora = 5;
                     }
                    else if($this->hora == 7)
                     {
                         $this->defineAmPm();
                         $this->hora = 6;
                     }
                    else if($this->hora == 8)
                     {
                         $this->defineAmPm();
                         $this->hora = 7;
                     }
                    else if($this->hora == 9)
                     {
                         $this->defineAmPm();
                         $this->hora = 8;
                     }
                    else if($this->hora == 10)
                     {
                         $this->defineAmPm();
                         $this->hora = 9;
                     }
                    else if($this->hora == 11)
                     {
                         $this->defineAmPm();
                         $this->hora = 10;
                     }
                    else if($this->hora == 12)
                     {
                         $this->hora = 11;
                     }
                    else 
                     {
                       $this->hora = ($this->hora + 11);
                     }
                     break;

        default:         		    
                     //relativo ao case 12.
                     //não é necessário implementá-lo pois é o valor de $this->hora padrão.		    
                     break;
      }
  }

 /**
  * Este método define a hora com base em inteiros negativos de -12 á -1, e é utilizado somente quando a propriedade  {@link $is_hora_full} é definida como false. Este método é chamado pelo método  {@link defineGMT}.
  * @name gmtNegativo12H
  * @access private
  * @return void
  * 
  * @param int $intGMT
  * Redefine os valores das propriedades {@link $hora} e {@link $ampm}.
  */

  private function gmtNegativo12H($intGMT)
  {
     #ini validacao
      if(!is_int($intGMT))
	  throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Aceito somente valores inteiros.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[4].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao  
      
      switch($intGMT)
      {
        case -1:
                      if($this->hora == 12)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {                         
                         $this->hora = 12;
                      }
                     else 
                     {
                        $this->hora = ($this->hora - 1);
                     }
                     break;

        case -2:
                      if($this->hora == 12)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 2);
                     }
                     break;

        case -3:
                      if($this->hora == 12)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 3);
                     }
                     break;

        case -4:
                      if($this->hora == 12)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 4);
                     }
                     break;

        case -5:
                      if($this->hora == 12)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->defineAmPm();
                         $this->hora = 11;
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 5);
                     }
                     break;

        case -6:
                      if($this->hora == 12)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 6);
                     }
                     break;

        case -7:
                      if($this->hora == 12)
                      {
                         $this->hora = 5;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 7)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 7);
                     }
                     break;

        case -8:
                      if($this->hora == 12)
                      {
                         $this->hora = 4;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 5;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 7)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 8)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 8);
                     }
                     break;

        case -9:
                      if($this->hora == 12)
                      {
                         $this->hora = 3;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 4;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 5;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 7)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 8)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 9)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 9);
                     }
                     break;

        case -10:
                      if($this->hora == 12)
                      {
                         $this->hora = 2;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 3;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 4;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 5;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 7)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 8)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 9)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 10)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 10);
                     }
                     break;

        case -11:
                      if($this->hora == 12)
                      {
                         $this->hora = 1;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 1)
                      {
                         $this->hora = 2;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 2)
                      {
                         $this->hora = 3;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 3)
                      {
                         $this->hora = 4;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 4)
                      {
                         $this->hora = 5;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 5)
                      {
                         $this->hora = 6;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 6)
                      {
                         $this->hora = 7;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 7)
                      {
                         $this->hora = 8;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 8)
                      {
                         $this->hora = 9;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 9)
                      {
                         $this->hora = 10;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 10)
                      {
                         $this->hora = 11;
                         $this->defineAmPm();
                      }
                      else if($this->hora == 11)
                      {
                         $this->hora = 12;
                      }
                     else 
                     {
                       $this->hora = ($this->hora - 11);
                     }
                     break;

        default: 	
		    $this->defineAmPm();
                     //relativo ao case 12.
                     //não é necessário implementá-lo pois é o valor de $this->hora padrão.
                     break;
      }
  }

 /**
  * Este método define a hora com base em inteiros positivos de 0 á 12, e é chamado pelo método {@link defineGMT} apenas se a propriedade {@link $is_hora_full} for verdadeira.
  * @name gmtPositivo24H
  * @access private
  * @return void
  * 
  * @param int $intGMT
  *  Redefine o valor da propriedade {@link $hora}.
  */

  private function gmtPositivo24H($intGMT)
  {          
     #ini validacao
      if(!is_int($intGMT))
	  throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Aceito somente valores inteiros.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[5].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao  
      
     switch($intGMT)
    {
      case 1:
                    if($this->hora == '23')
                     {
                         $this->hora = 0;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 1);
                     }
                     break;

      case 2:
                    if($this->hora == '22')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 1;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 2);
                     }
                     break;

      case 3:
                    if($this->hora == '21')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 2;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 3);
                     }
                     break;

      case 4:
                    if($this->hora == '20')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 3;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 4);
                     }
                     break;

      case 5:
                    if($this->hora == '19')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '24')
                    {
                      $this->hora = 4;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 5);
                     }
                     break;

      case 6:
                    if($this->hora == '18')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 5;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 6);
                     }
                     break;

      case 7:
                    if($this->hora == '17')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 6;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 7);
                     }
                     break;

      case 8:
                    if($this->hora == '16')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '17')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 6;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 7;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 8);
                     }
                     break;

      case 9:
                    if($this->hora == '15')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '16')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '17')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 6;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 7;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 8;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 9);
                     }
                     break;

      case 10:
                    if($this->hora == '14')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '15')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '16')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '17')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 6;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 7;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 8;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 9;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 10);
                     }
                     break;

      case 11:
                    if($this->hora == '13')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '14')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '15')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '16')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '17')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 6;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 7;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 8;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 9;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 10;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 11);
                     }
                     break;

      case 12:
                    if($this->hora == '12')
                     {
                         $this->hora = 0;
                     }
                     else if($this->hora == '13')
                    {
                      $this->hora = 1;
                     }
                     else if($this->hora == '14')
                    {
                      $this->hora = 2;
                     }
                     else if($this->hora == '15')
                    {
                      $this->hora = 3;
                     }
                     else if($this->hora == '16')
                    {
                      $this->hora = 4;
                     }
                     else if($this->hora == '17')
                    {
                      $this->hora = 5;
                     }
                     else if($this->hora == '18')
                    {
                      $this->hora = 6;
                     }
                     else if($this->hora == '19')
                    {
                      $this->hora = 7;
                     }
                     else if($this->hora == '20')
                    {
                      $this->hora = 8;
                     }
                     else if($this->hora == '21')
                    {
                      $this->hora = 9;
                     }
                     else if($this->hora == '22')
                    {
                      $this->hora = 10;
                     }
                     else if($this->hora == '23')
                    {
                      $this->hora = 11;
                     }
                     else 
                     {
                       $this->hora = ($this->hora + 12);
                     }
                     break;
   }
}


 /**
  * Este método define a hora com base em inteiros negativos de -12 á -1, e é chamado pelo método {@link defineGMT} apenas se a propriedade {@link $is_hora_full} for verdadeira.
  * @name gmtNegativo24H
  * @access private
  * @return void
  * 
  * @param int $intGMT
  * Redefine o valor da propriedade {@link $hora}.
  */

  private function gmtNegativo24H($intGMT)
  {                 
     #ini validacao
      if(!is_int($intGMT))
	  throw new Exception('Primeiro parâmetro <b>$intGMT</b> inválido ! Aceito somente valores inteiros.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[6].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao  
      
     switch($intGMT)
    {
      case -1:
                    if($this->hora == '00')
                     {
                         $this->hora = 23;
                     }
                     else 
                     {
                       $this->hora = ($this->hora - 1);
                     }

                     break;      

      case -2:
                    if($this->hora == '00')
                     {
                         $this->hora = 22;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 23;
                     }  
                     else 
                     {
                       $this->hora = ($this->hora - 2);
                     }
                  break; 

      case -3:
                    if($this->hora == '00')
                     {
                         $this->hora = 21;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 22;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 23;
                     }  
                     else 
                     {
                       $this->hora = ($this->hora - 3);
                     }
                  break;

      case -4:
                    if($this->hora == '00')
                     {
                         $this->hora = 20;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 21;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 22;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 23;
                     }    
                     else 
                     {
                       $this->hora = ($this->hora - 4);
                     }
                  break;   

      case -5:
                    if($this->hora == '00')
                     {
                         $this->hora = 19;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 20;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 21;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 22;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 23;
                     }    
                     else 
                     {
                       $this->hora = ($this->hora - 5);
                     }
                  break;   

      case -6:
                    if($this->hora == '00')
                     {
                         $this->hora = 18;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 19;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 20;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 21;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 22;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 23;
                     }    
                     else 
                     {
                       $this->hora = ($this->hora - 6);
                     }
                  break;   

      case -7:
                    if($this->hora == '00')
                     {
                         $this->hora = 17;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 18;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 19;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 20;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 21;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 22;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 23;
                     }    
                     else 
                     {
                       $this->hora = ($this->hora - 7);
                     }
                     break;

      case -8:
                    if($this->hora == '00')
                     {
                         $this->hora = 16;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 17;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 18;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 19;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 20;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 21;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 22;
                     }    
                     else if($this->hora == '07')
                    {
                      $this->hora = 23;
                     }    
                     else 
                     {
                       $this->hora = ($this->hora - 8);
                     }
                     break;

      case -9:
                    if($this->hora == '00')
                     {
                         $this->hora = 15;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 16;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 17;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 18;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 19;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 20;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 21;
                     }    
                     else if($this->hora == '07')
                    {
                      $this->hora = 22;
                     }    
                     else if($this->hora == '08')
                    {
                      $this->hora = 23;
                     }   
                     else 
                     {
                       $this->hora = ($this->hora - 9);
                     }
                     break;

      case -10:
                    if($this->hora == '00')
                     {
                         $this->hora = 14;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 15;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 16;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 17;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 18;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 19;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 20;
                     }    
                     else if($this->hora == '07')
                    {
                      $this->hora = 21;
                     }    
                     else if($this->hora == '08')
                    {
                      $this->hora = 22;
                     } 
                     else if($this->hora == '09')
                    {
                      $this->hora = 23;
                     }   
                     else 
                     {
                       $this->hora = ($this->hora - 10);
                     }
                     break;

      case -11:
                    if($this->hora == '00')
                     {
                         $this->hora = 13;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 14;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 15;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 16;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 17;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 18;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 19;
                     }    
                     else if($this->hora == '07')
                    {
                      $this->hora = 20;
                     }    
                     else if($this->hora == '08')
                    {
                      $this->hora = 21;
                     } 
                     else if($this->hora == '09')
                    {
                      $this->hora = 22;
                     }   
                     else if($this->hora == '10')
                    {
                      $this->hora = 23;
                     }   
                     else 
                     {
                       $this->hora = ($this->hora - 11);
                     }
                     break;

      case -12:
                    if($this->hora == '00')
                     {
                         $this->hora = 12;
                     }
                     else if($this->hora == '01')
                    {
                      $this->hora = 13;
                     }  
                     else if($this->hora == '02')
                    {
                      $this->hora = 14;
                     }  
                     else if($this->hora == '03')
                    {
                      $this->hora = 15;
                     }    
                     else if($this->hora == '04')
                    {
                      $this->hora = 16;
                     }    
                     else if($this->hora == '05')
                    {
                      $this->hora = 17;
                     }    
                     else if($this->hora == '06')
                    {
                      $this->hora = 18;
                     }    
                     else if($this->hora == '07')
                    {
                      $this->hora = 19;
                     }    
                     else if($this->hora == '08')
                    {
                      $this->hora = 20;
                     } 
                     else if($this->hora == '09')
                    {
                      $this->hora = 21;
                     }   
                     else if($this->hora == '10')
                    {
                      $this->hora = 22;
                     } 
                     else if($this->hora == '11')
                    {
                      $this->hora = 23;
                     }   
                     else 
                     {
                       $this->hora = ($this->hora - 12);
                     }
                     break;
       }
   }

 /**
  * Método que retorna a hora modificada pelo método {@link defineGMT}. Exemplo similar ao do método {@link getSegundoGMT}. Normalmente retorna inteiro. Somente retorna string quando a hora é '00'.
  *
  * @name getHoraGMT
  * @access public
  * @return mixed
  */

  public function getHoraGMT()
  {
    #ini validacao
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[7].' da classe '.$c[0].':</b> <em>Não há argumentos implementados !</em>');	
    }      
    
     if(!preg_match('/^00/',$this->hora) && !preg_match('/^0[1-9]/',$this->hora))
     {
     
      if($this->hora <= 9)
      {
	 $this->hora = '0' . $this->hora;
      }
    }
    #fim validacao  
    
    return $this->hora; 
  }

 /**
  * Método que retorna o minuto. O minuto também pode ser recuperado através do método da classe base {@link getMinuto}. Exemplo similar ao do método {@link getSegundoGMT}.
  * @name getMinutoGMT
  * @access public
  * @return int
  */

  public function getMinutoGMT()
  {
    #ini validacao      
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[8].' da classe '.$c[0].':</b> <em>Nenhum argumento implementado !</em>');	
    }      
    #fim validacao  

     return $this->getMinuto(); 
  }

 /**
  * Método que retorna o segundo. O segundo também pode ser recuperado através do método da classe base {@link getSegundo}.
  *
  * <b>Exemplo de utilização da classe</b>
  *
  * <code>  
  * require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Horas/class.hora_gmt.php'); 
  * $tempo = new Hora_GMT();
  *
  * echo "Chamando o método da classe base: ". $tempo->getSegundo().'<br />';
  * echo "Invocando o método da classe atual: " . $tempo->getSegundoGMT();
  * </code>
  * 
  * @name getSegundoGMT
  * @return int
  * @access public
  */

  public function getSegundoGMT()
  {
    #ini validacao      
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[9].' da classe '.$c[0].':</b> <em>Não há argumentos implementados !</em>');	
    }      
    #fim validacao  
      
     return $this->getSegundo(); 
  }

 /**
  * Método utilizado para retornar o valor da propriedade {@link $ampm}. Você pode invocar também o método da classe base {@link getAmPm} se você não utilizar o método {@link defineGMT}.
  *
  * <b>Exemplo de utilização da classe</b>
  *
  * <code>
  * require('/lib/FabianoSantosFramework/PHP/Codigos/Tempo/Horas/class.hora_gmt.php'); 
  * $tempo = new Hora_GMT();
  *
  * echo "Retorna em minúsculo: ". $tempo->getAmPm().'<br />';
  * echo "Retorna em maiúsculo: ". $tempo->getAmPm(true).'<br /><br />';
  *
  * echo "Chamando pela classe base: ". $tempo->getAmPm(). '<br />';
  * echo "Hora e ampm: ". $tempo->getHoraGMT().' '.$tempo->getAmPmGMT();
  * </code>
  * 
  * @name getAmPmGMT
  * @access public
  * @return int
  * @param bool $is_maiusculo
  * Define o valor de retorno da propriedade {@link $ampm}, como maiúsculo/minúsculo.
  */

  public function getAmPmGMT($is_maiusculo = false)
  {
     #ini validacao
      if(!is_bool($is_maiusculo))
	  throw new Exception('Primeiro parâmetro <b>$is_maiusculo</b> inválido ! Aceito somente valores booleanos.');	  
      else 
      {
	$numargs = func_num_args();
	
	if($numargs>1) 
	{
	  $c=get_class_methods($this);
	  
	  throw new Exception('<b>Erro no método '.$c[10].' da classe '.$c[0].':</b> <em>Número de argumentos inválidos !</em>');	
	}
      }
      #fim validacao

      
    if(!$is_maiusculo)
    return strtolower($this->ampm); 
    else return strtoupper($this->ampm);
  }
  
 /**
  * Método utilizado para retornar quatro formatos de hora.
  * 
  * <ul>
  *	<li>01 - A hora no padrão de 00 à 23 com o horário GMT 00:00: formato "horas:minutos".</li>
  *	<li>02 - A hora no padrão de 00 à 23 com o horário GMT definido pelo usuário: formato "horas:minutos".</li>
  *
  *	<li>03 - A hora no padrão de 01 à 12 com o horário GMT 00:00: formato "horas:minutos am/pm".</li>
  *	<li>04 - A hora no padrão de 01 à 12 com o horário GMT definido pelo usuário: formato "horas:minutos am/pm".</li>
  * </ul>
  *
  * <b>Exemplo 01 de utilização da classe</b>
  *
  * <code>
  * require('MinhaBiblioteca/Tempo/Horas/class.hora_gmt.php');
  * $tempo = new Hora_GMT(true, true);
  *
  * $tempo->defineGMT(-3);
  * $tempo->Imprimir();
  * </code>  
  *
  * @name Imprimir
  * @access public
  * @return void
  */

  public function Imprimir()
  {     
    #ini validacao      
    $numargs = func_num_args();
    
    if($numargs>0) 
    {
      $c=get_class_methods($this);
      
      throw new Exception('<b>Erro no método '.$c[11].' da classe '.$c[0].':</b> <em>Não há argumentos implementados !</em>');	
    }      
    #fim validacao  
    
      if($this->is_hora_full)
     {
        if($this->getHora() == $this->getHoraGMT())
        {
           echo $this->getHora() .':'. $this->getMinuto();
        }
        else
              {
                echo $this->getHoraGMT() .':'. $this->getMinuto();
              }
     }
    else
          {
              if($this->getHora() == $this->getHoraGMT())
              {	
		if(!empty($this->update_ampm))
		{
		  $ampm = $this->getAmPm($this->is_ampm_maiusculo);

		  if($ampm=='AM') $ampm='PM'; else if($ampm=='PM') $ampm='AM';
		  else if($ampm=='am') $ampm='pm'; else if($ampm=='pm') $ampm='am';
		}
		else $ampm = $this->getAmPm($this->is_ampm_maiusculo);

                 echo $this->getHoraGMT() .':'. $this->getMinuto() .  ' '.$ampm;

              }
              else
                  {            
                      echo $this->getHoraGMT() .':'. $this->getMinutoGMT() . ' ' . $this->getAmPmGMT($this->is_ampm_maiusculo);
                  }
          }
  }
}
?>