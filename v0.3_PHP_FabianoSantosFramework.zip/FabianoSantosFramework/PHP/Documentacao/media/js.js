/* JS Base */
window.onload=function()
{
  $url=document.getElementById('logourl');
  $url.style.cursor='pointer';
  $url.onclick=function()
  {
    document.location.href='http://fsf.fabianosantos.net';       
  }
}